package com.allinone.database;

import com.allinone.AllInOnePlugin;
import org.bukkit.configuration.file.FileConfiguration;

import java.io.File;
import java.sql.*;
import java.util.logging.Level;

public class DatabaseManager {
    
    private final AllInOnePlugin plugin;
    private Connection connection;
    
    public DatabaseManager(AllInOnePlugin plugin) {
        this.plugin = plugin;
        initializeDatabase();
    }
    
    private void initializeDatabase() {
        try {
            File dataFolder = plugin.getDataFolder();
            if (!dataFolder.exists()) {
                dataFolder.mkdirs();
            }
            
            String url = "jdbc:sqlite:" + dataFolder.getAbsolutePath() + "/database.db";
            connection = DriverManager.getConnection(url);
            
            createTables();
            plugin.getLogger().info("Base de datos SQLite inicializada correctamente!");
            
        } catch (SQLException e) {
            plugin.getLogger().log(Level.SEVERE, "Error al conectar con la base de datos", e);
        }
    }
    
    private void createTables() throws SQLException {
        // Tabla de economía
        executeUpdate("CREATE TABLE IF NOT EXISTS economy (" +
                "uuid VARCHAR(36) PRIMARY KEY," +
                "balance DECIMAL(10,2) DEFAULT 0.00" +
                ")");
        
        // Tabla de homes
        executeUpdate("CREATE TABLE IF NOT EXISTS homes (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "uuid VARCHAR(36)," +
                "name VARCHAR(50)," +
                "world VARCHAR(50)," +
                "x DOUBLE," +
                "y DOUBLE," +
                "z DOUBLE," +
                "yaw FLOAT," +
                "pitch FLOAT" +
                ")");
        
        // Tabla de warps
        executeUpdate("CREATE TABLE IF NOT EXISTS warps (" +
                "name VARCHAR(50) PRIMARY KEY," +
                "world VARCHAR(50)," +
                "x DOUBLE," +
                "y DOUBLE," +
                "z DOUBLE," +
                "yaw FLOAT," +
                "pitch FLOAT" +
                ")");
        
        // Tabla de rangos
        executeUpdate("CREATE TABLE IF NOT EXISTS player_ranks (" +
                "uuid VARCHAR(36) PRIMARY KEY," +
                "rank_name VARCHAR(50)," +
                "prefix VARCHAR(100)," +
                "suffix VARCHAR(100)" +
                ")");
        
        // Tabla de nicks
        executeUpdate("CREATE TABLE IF NOT EXISTS player_nicks (" +
                "uuid VARCHAR(36) PRIMARY KEY," +
                "nickname VARCHAR(50)," +
                "chat_color VARCHAR(20)" +
                ")");
        
        // Tabla de kits usados
        executeUpdate("CREATE TABLE IF NOT EXISTS kit_usage (" +
                "uuid VARCHAR(36)," +
                "kit_name VARCHAR(50)," +
                "last_used BIGINT," +
                "PRIMARY KEY (uuid, kit_name)" +
                ")");
        
        // Tabla de subastas
        executeUpdate("CREATE TABLE IF NOT EXISTS auctions (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "seller_uuid VARCHAR(36)," +
                "item_data TEXT," +
                "starting_price DECIMAL(10,2)," +
                "current_bid DECIMAL(10,2)," +
                "bidder_uuid VARCHAR(36)," +
                "end_time BIGINT," +
                "active BOOLEAN DEFAULT TRUE" +
                ")");
        
        // Tabla de protecciones
        executeUpdate("CREATE TABLE IF NOT EXISTS protections (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "owner_uuid VARCHAR(36)," +
                "world VARCHAR(50)," +
                "x INTEGER," +
                "y INTEGER," +
                "z INTEGER," +
                "protection_type VARCHAR(20)" +
                ")");
        
        // Tabla de spawn
        executeUpdate("CREATE TABLE IF NOT EXISTS spawn_location (" +
                "world VARCHAR(50)," +
                "x DOUBLE," +
                "y DOUBLE," +
                "z DOUBLE," +
                "yaw FLOAT," +
                "pitch FLOAT" +
                ")");
    }
    
    public void executeUpdate(String sql, Object... params) throws SQLException {
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                stmt.setObject(i + 1, params[i]);
            }
            stmt.executeUpdate();
        }
    }
    
    public ResultSet executeQuery(String sql, Object... params) throws SQLException {
        PreparedStatement stmt = connection.prepareStatement(sql);
        for (int i = 0; i < params.length; i++) {
            stmt.setObject(i + 1, params[i]);
        }
        return stmt.executeQuery();
    }
    
    public Connection getConnection() {
        return connection;
    }
    
    public void close() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Error al cerrar la base de datos", e);
            }
        }
    }
}