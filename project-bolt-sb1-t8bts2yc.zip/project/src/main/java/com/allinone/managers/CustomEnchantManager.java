package com.allinone.managers;

import com.allinone.AllInOnePlugin;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class CustomEnchantManager implements Listener {
    
    private final AllInOnePlugin plugin;
    private final Random random = new Random();
    private final Map<String, CustomEnchant> customEnchants = new HashMap<>();
    
    public CustomEnchantManager(AllInOnePlugin plugin) {
        this.plugin = plugin;
        initializeCustomEnchants();
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }
    
    private void initializeCustomEnchants() {
        // Lightning - Invoca rayos
        customEnchants.put("lightning", new CustomEnchant("Lightning", "Invoca rayos al atacar", 15));
        
        // Explosive - Explosiones
        customEnchants.put("explosive", new CustomEnchant("Explosive", "Causa explosiones", 10));
        
        // Vampire - Roba vida
        customEnchants.put("vampire", new CustomEnchant("Vampire", "Roba vida del enemigo", 20));
        
        // Freeze - Congela enemigos
        customEnchants.put("freeze", new CustomEnchant("Freeze", "Congela a los enemigos", 25));
        
        // Poison - Envenena
        customEnchants.put("poison", new CustomEnchant("Poison", "Envenena a los enemigos", 30));
        
        // Speed - Da velocidad
        customEnchants.put("speed", new CustomEnchant("Speed", "Otorga velocidad al atacar", 20));
        
        // Jump - Impulso hacia arriba
        customEnchants.put("jump", new CustomEnchant("Jump", "Impulsa enemigos hacia arriba", 15));
        
        // Blind - Ceguera
        customEnchants.put("blind", new CustomEnchant("Blind", "Ciega a los enemigos", 25));
        
        // Fire - Fuego mejorado
        customEnchants.put("fire", new CustomEnchant("Fire", "Fuego intenso y duradero", 20));
        
        // Teleport - Teletransporte
        customEnchants.put("teleport", new CustomEnchant("Teleport", "Teletransporta al enemigo", 5));
    }
    
    public ItemStack addCustomEnchant(ItemStack item, String enchantName, int level) {
        if (!customEnchants.containsKey(enchantName.toLowerCase())) return item;
        
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        
        List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        
        CustomEnchant enchant = customEnchants.get(enchantName.toLowerCase());
        String enchantLine = ChatColor.AQUA + enchant.getName() + " " + level;
        
        // Remover encantamiento existente si ya está
        lore.removeIf(line -> line.contains(enchant.getName()));
        
        // Añadir nuevo encantamiento
        lore.add(enchantLine);
        lore.add(ChatColor.GRAY + enchant.getDescription());
        
        meta.setLore(lore);
        item.setItemMeta(meta);
        
        return item;
    }
    
    public boolean hasCustomEnchant(ItemStack item, String enchantName) {
        if (item == null || !item.hasItemMeta() || !item.getItemMeta().hasLore()) return false;
        
        CustomEnchant enchant = customEnchants.get(enchantName.toLowerCase());
        if (enchant == null) return false;
        
        for (String line : item.getItemMeta().getLore()) {
            if (line.contains(enchant.getName())) {
                return true;
            }
        }
        return false;
    }
    
    public int getCustomEnchantLevel(ItemStack item, String enchantName) {
        if (!hasCustomEnchant(item, enchantName)) return 0;
        
        CustomEnchant enchant = customEnchants.get(enchantName.toLowerCase());
        
        for (String line : item.getItemMeta().getLore()) {
            if (line.contains(enchant.getName())) {
                String[] parts = line.split(" ");
                if (parts.length > 1) {
                    try {
                        return Integer.parseInt(parts[parts.length - 1]);
                    } catch (NumberFormatException e) {
                        return 1;
                    }
                }
            }
        }
        return 1;
    }
    
    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) return;
        if (!(event.getEntity() instanceof LivingEntity)) return;
        
        Player attacker = (Player) event.getDamager();
        LivingEntity victim = (LivingEntity) event.getEntity();
        ItemStack weapon = attacker.getInventory().getItemInMainHand();
        
        if (weapon == null || weapon.getType() == Material.AIR) return;
        
        // Procesar cada encantamiento custom
        processCustomEnchants(attacker, victim, weapon, event);
    }
    
    private void processCustomEnchants(Player attacker, LivingEntity victim, ItemStack weapon, EntityDamageByEntityEvent event) {
        // Lightning
        if (hasCustomEnchant(weapon, "lightning")) {
            int level = getCustomEnchantLevel(weapon, "lightning");
            if (random.nextInt(100) < customEnchants.get("lightning").getChance() + (level * 5)) {
                victim.getWorld().strikeLightning(victim.getLocation());
                attacker.sendMessage(ChatColor.YELLOW + "⚡ ¡Rayo invocado!");
            }
        }
        
        // Explosive
        if (hasCustomEnchant(weapon, "explosive")) {
            int level = getCustomEnchantLevel(weapon, "explosive");
            if (random.nextInt(100) < customEnchants.get("explosive").getChance() + (level * 3)) {
                victim.getWorld().createExplosion(victim.getLocation(), 2.0f + level, false, false);
                attacker.sendMessage(ChatColor.RED + "💥 ¡Explosión!");
            }
        }
        
        // Vampire
        if (hasCustomEnchant(weapon, "vampire")) {
            int level = getCustomEnchantLevel(weapon, "vampire");
            if (random.nextInt(100) < customEnchants.get("vampire").getChance() + (level * 5)) {
                double healAmount = event.getDamage() * 0.3 * level;
                attacker.setHealth(Math.min(attacker.getMaxHealth(), attacker.getHealth() + healAmount));
                attacker.sendMessage(ChatColor.DARK_RED + "🩸 ¡Vida robada!");
            }
        }
        
        // Freeze
        if (hasCustomEnchant(weapon, "freeze")) {
            int level = getCustomEnchantLevel(weapon, "freeze");
            if (random.nextInt(100) < customEnchants.get("freeze").getChance()) {
                victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 60 + (level * 20), level));
                victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_DIGGING, 60 + (level * 20), level));
                attacker.sendMessage(ChatColor.AQUA + "❄️ ¡Enemigo congelado!");
            }
        }
        
        // Poison
        if (hasCustomEnchant(weapon, "poison")) {
            int level = getCustomEnchantLevel(weapon, "poison");
            if (random.nextInt(100) < customEnchants.get("poison").getChance()) {
                victim.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 100 + (level * 40), level - 1));
                attacker.sendMessage(ChatColor.GREEN + "☠️ ¡Enemigo envenenado!");
            }
        }
        
        // Speed
        if (hasCustomEnchant(weapon, "speed")) {
            int level = getCustomEnchantLevel(weapon, "speed");
            if (random.nextInt(100) < customEnchants.get("speed").getChance()) {
                attacker.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100 + (level * 20), level - 1));
                attacker.sendMessage(ChatColor.YELLOW + "💨 ¡Velocidad aumentada!");
            }
        }
        
        // Jump
        if (hasCustomEnchant(weapon, "jump")) {
            int level = getCustomEnchantLevel(weapon, "jump");
            if (random.nextInt(100) < customEnchants.get("jump").getChance()) {
                victim.setVelocity(victim.getVelocity().setY(1.0 + (level * 0.5)));
                attacker.sendMessage(ChatColor.WHITE + "🚀 ¡Enemigo impulsado!");
            }
        }
        
        // Blind
        if (hasCustomEnchant(weapon, "blind")) {
            int level = getCustomEnchantLevel(weapon, "blind");
            if (random.nextInt(100) < customEnchants.get("blind").getChance()) {
                victim.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60 + (level * 20), 0));
                attacker.sendMessage(ChatColor.DARK_GRAY + "👁️ ¡Enemigo cegado!");
            }
        }
        
        // Fire
        if (hasCustomEnchant(weapon, "fire")) {
            int level = getCustomEnchantLevel(weapon, "fire");
            if (random.nextInt(100) < customEnchants.get("fire").getChance()) {
                victim.setFireTicks(100 + (level * 60));
                attacker.sendMessage(ChatColor.RED + "🔥 ¡Fuego intenso!");
            }
        }
        
        // Teleport
        if (hasCustomEnchant(weapon, "teleport")) {
            int level = getCustomEnchantLevel(weapon, "teleport");
            if (random.nextInt(100) < customEnchants.get("teleport").getChance()) {
                Location randomLoc = getRandomNearbyLocation(victim.getLocation(), 10 + (level * 5));
                victim.teleport(randomLoc);
                attacker.sendMessage(ChatColor.LIGHT_PURPLE + "🌀 ¡Enemigo teletransportado!");
            }
        }
    }
    
    private Location getRandomNearbyLocation(Location center, int radius) {
        double angle = random.nextDouble() * 2 * Math.PI;
        double distance = random.nextDouble() * radius;
        
        double x = center.getX() + (distance * Math.cos(angle));
        double z = center.getZ() + (distance * Math.sin(angle));
        double y = center.getWorld().getHighestBlockYAt((int) x, (int) z) + 1;
        
        return new Location(center.getWorld(), x, y, z);
    }
    
    public ItemStack createRandomEnchantedBook() {
        ItemStack book = new ItemStack(Material.ENCHANTED_BOOK);
        ItemMeta meta = book.getItemMeta();
        
        // Seleccionar encantamiento aleatorio
        String[] enchantNames = customEnchants.keySet().toArray(new String[0]);
        String randomEnchant = enchantNames[random.nextInt(enchantNames.length)];
        int randomLevel = random.nextInt(3) + 1; // Nivel 1-3
        
        CustomEnchant enchant = customEnchants.get(randomEnchant);
        
        meta.setDisplayName(ChatColor.DARK_PURPLE + "Libro de " + enchant.getName());
        meta.setLore(Arrays.asList(
            ChatColor.AQUA + enchant.getName() + " " + randomLevel,
            ChatColor.GRAY + enchant.getDescription(),
            "",
            ChatColor.YELLOW + "Usa en yunque para aplicar"
        ));
        
        book.setItemMeta(meta);
        return book;
    }
    
    // Clase interna CustomEnchant
    private static class CustomEnchant {
        private final String name;
        private final String description;
        private final int chance;
        
        public CustomEnchant(String name, String description, int chance) {
            this.name = name;
            this.description = description;
            this.chance = chance;
        }
        
        public String getName() { return name; }
        public String getDescription() { return description; }
        public int getChance() { return chance; }
    }
}