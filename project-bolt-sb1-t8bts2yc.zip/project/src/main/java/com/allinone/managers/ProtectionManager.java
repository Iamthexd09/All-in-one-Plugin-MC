package com.allinone.managers;

import com.allinone.AllInOnePlugin;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.HashMap;

public class ProtectionManager {
    
    private final AllInOnePlugin plugin;
    private final Map<Material, ProtectionStone> protectionStones;
    private FileConfiguration protectionConfig;
    
    public ProtectionManager(AllInOnePlugin plugin) {
        this.plugin = plugin;
        this.protectionStones = new HashMap<>();
        loadProtectionConfig();
        initializeProtectionStones();
    }
    
    private void loadProtectionConfig() {
        File configFile = new File(plugin.getDataFolder(), "protections.yml");
        if (!configFile.exists()) {
            plugin.saveResource("protections.yml", false);
        }
        protectionConfig = YamlConfiguration.loadConfiguration(configFile);
    }
    
    private void initializeProtectionStones() {
        for (String key : protectionConfig.getConfigurationSection("stones").getKeys(false)) {
            String path = "stones." + key;
            String materialName = protectionConfig.getString(path + ".material");
            Material material = Material.valueOf(materialName);
            
            ProtectionStone stone = new ProtectionStone(
                protectionConfig.getString(path + ".name"),
                protectionConfig.getString(path + ".description"),
                material,
                protectionConfig.getBoolean(path + ".enchanted", false),
                protectionConfig.getBoolean(path + ".hide_enchants", false),
                protectionConfig.getDouble(path + ".cost"),
                protectionConfig.getInt(path + ".radius"),
                protectionConfig.getString(path + ".protection_level"),
                protectionConfig.getStringList(path + ".lore")
            );
            
            protectionStones.put(material, stone);
        }
    }
    
    public ItemStack createProtectionStone(Material material) {
        ProtectionStone stone = protectionStones.get(material);
        if (stone == null) return null;
        
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', stone.getName()));
        
        List<String> lore = new ArrayList<>();
        for (String line : stone.getLore()) {
            lore.add(ChatColor.translateAlternateColorCodes('&', line));
        }
        meta.setLore(lore);
        
        if (stone.isEnchanted()) {
            meta.addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 1, true);
            if (stone.isHideEnchants()) {
                meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            }
        }
        
        item.setItemMeta(meta);
        return item;
    }
    
    public boolean createProtection(Player player, Location location, Material stoneType) {
        ProtectionStone stone = protectionStones.get(stoneType);
        if (stone == null) return false;
        
        // Verificar dinero
        if (!plugin.getEconomyManager().removeBalance(player.getUniqueId(), stone.getCost())) {
            player.sendMessage(ChatColor.translateAlternateColorCodes('&', 
                protectionConfig.getString("messages.insufficient_funds")
                    .replace("{cost}", String.valueOf(stone.getCost()))));
            return false;
        }
        
        try {
            plugin.getDatabaseManager().executeUpdate(
                "INSERT INTO protections (owner_uuid, world, x, y, z, protection_type) VALUES (?, ?, ?, ?, ?, ?)",
                player.getUniqueId().toString(), location.getWorld().getName(),
                location.getBlockX(), location.getBlockY(), location.getBlockZ(), stone.getProtectionLevel());
            
            player.sendMessage(ChatColor.translateAlternateColorCodes('&', 
                protectionConfig.getString("messages.protection_created")));
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            // Devolver dinero si hay error
            plugin.getEconomyManager().addBalance(player.getUniqueId(), stone.getCost());
            return false;
        }
    }
    
    public boolean isProtected(Location location) {
        return getProtectionOwner(location) != null;
    }
    
    private int getProtectionRadius(Location location) {
        try {
            ResultSet rs = plugin.getDatabaseManager().executeQuery(
                "SELECT protection_type FROM protections WHERE world = ? AND " +
                "x = ? AND y = ? AND z = ? LIMIT 1",
                location.getWorld().getName(), location.getBlockX(), 
                location.getBlockY(), location.getBlockZ());
            
            if (rs.next()) {
                String protectionType = rs.getString("protection_type");
                // Buscar el radio basado en el tipo de protección
                for (ProtectionStone stone : protectionStones.values()) {
                    if (stone.getProtectionLevel().equals(protectionType)) {
                        return stone.getRadius();
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 4; // Radio por defecto
    }
    
    public UUID getProtectionOwner(Location location) {
        try {
            // Buscar protecciones cercanas con diferentes radios
            ResultSet rs = plugin.getDatabaseManager().executeQuery(
                "SELECT owner_uuid, x, y, z, protection_type FROM protections WHERE world = ?",
                location.getWorld().getName());
            
            while (rs.next()) {
                int protX = rs.getInt("x");
                int protY = rs.getInt("y");
                int protZ = rs.getInt("z");
                String protectionType = rs.getString("protection_type");
                
                // Obtener radio de protección
                int radius = 4; // Por defecto
                for (ProtectionStone stone : protectionStones.values()) {
                    if (stone.getProtectionLevel().equals(protectionType)) {
                        radius = stone.getRadius();
                        break;
                    }
                }
                
                // Verificar si está dentro del radio
                if (Math.abs(location.getBlockX() - protX) <= radius &&
                    Math.abs(location.getBlockY() - protY) <= radius &&
                    Math.abs(location.getBlockZ() - protZ) <= radius) {
                    return UUID.fromString(rs.getString("owner_uuid"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public boolean canTeleportTo(Player player, Location location) {
        if (!isProtected(location)) return true;
        
        UUID owner = getProtectionOwner(location);
        return owner != null && owner.equals(player.getUniqueId());
    }
    
    public boolean isProtectionStone(Material material) {
        return protectionStones.containsKey(material);
    }
    
    public ProtectionStone getProtectionStone(Material material) {
        return protectionStones.get(material);
    }
    
    // Clase interna ProtectionStone
    public static class ProtectionStone {
        private final String name;
        private final String description;
        private final Material material;
        private final boolean enchanted;
        private final boolean hideEnchants;
        private final double cost;
        private final int radius;
        private final String protectionLevel;
        private final List<String> lore;
        
        public ProtectionStone(String name, String description, Material material, 
                             boolean enchanted, boolean hideEnchants, double cost, 
                             int radius, String protectionLevel, List<String> lore) {
            this.name = name;
            this.description = description;
            this.material = material;
            this.enchanted = enchanted;
            this.hideEnchants = hideEnchants;
            this.cost = cost;
            this.radius = radius;
            this.protectionLevel = protectionLevel;
            this.lore = lore;
        }
        
        // Getters
        public String getName() { return name; }
        public String getDescription() { return description; }
        public Material getMaterial() { return material; }
        public boolean isEnchanted() { return enchanted; }
        public boolean isHideEnchants() { return hideEnchants; }
        public double getCost() { return cost; }
        public int getRadius() { return radius; }
        public String getProtectionLevel() { return protectionLevel; }
        public List<String> getLore() { return lore; }
        }
    }
}