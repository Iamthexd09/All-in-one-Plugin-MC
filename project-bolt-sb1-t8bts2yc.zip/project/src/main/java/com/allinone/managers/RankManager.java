package com.allinone.managers;

import com.allinone.AllInOnePlugin;
import org.bukkit.ChatColor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

public class RankManager {
    
    private final AllInOnePlugin plugin;
    
    public RankManager(AllInOnePlugin plugin) {
        this.plugin = plugin;
    }
    
    public void setPlayerRank(UUID playerUUID, String rankName, String prefix, String suffix) {
        try {
            plugin.getDatabaseManager().executeUpdate(
                "INSERT OR REPLACE INTO player_ranks (uuid, rank_name, prefix, suffix) VALUES (?, ?, ?, ?)",
                playerUUID.toString(), rankName, prefix, suffix);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public String getPlayerRank(UUID playerUUID) {
        try {
            ResultSet rs = plugin.getDatabaseManager().executeQuery(
                "SELECT rank_name FROM player_ranks WHERE uuid = ?", playerUUID.toString());
            
            if (rs.next()) {
                return rs.getString("rank_name");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "Usuario"; // Rango por defecto
    }
    
    public String getPlayerPrefix(UUID playerUUID) {
        try {
            ResultSet rs = plugin.getDatabaseManager().executeQuery(
                "SELECT prefix FROM player_ranks WHERE uuid = ?", playerUUID.toString());
            
            if (rs.next()) {
                String prefix = rs.getString("prefix");
                return prefix != null ? ChatColor.translateAlternateColorCodes('&', prefix) : "";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ChatColor.GRAY + "[Usuario] ";
    }
    
    public String getPlayerSuffix(UUID playerUUID) {
        try {
            ResultSet rs = plugin.getDatabaseManager().executeQuery(
                "SELECT suffix FROM player_ranks WHERE uuid = ?", playerUUID.toString());
            
            if (rs.next()) {
                String suffix = rs.getString("suffix");
                return suffix != null ? ChatColor.translateAlternateColorCodes('&', suffix) : "";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "";
    }
    
    public void setPlayerNickname(UUID playerUUID, String nickname, String chatColor) {
        try {
            plugin.getDatabaseManager().executeUpdate(
                "INSERT OR REPLACE INTO player_nicks (uuid, nickname, chat_color) VALUES (?, ?, ?)",
                playerUUID.toString(), nickname, chatColor);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public String getPlayerNickname(UUID playerUUID) {
        try {
            ResultSet rs = plugin.getDatabaseManager().executeQuery(
                "SELECT nickname, chat_color FROM player_nicks WHERE uuid = ?", playerUUID.toString());
            
            if (rs.next()) {
                String nickname = rs.getString("nickname");
                String color = rs.getString("chat_color");
                
                if (nickname != null) {
                    return color != null ? 
                        ChatColor.translateAlternateColorCodes('&', color + nickname) : 
                        nickname;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}