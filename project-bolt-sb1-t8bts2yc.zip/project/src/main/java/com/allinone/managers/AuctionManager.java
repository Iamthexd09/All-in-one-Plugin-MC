package com.allinone.managers;

import com.allinone.AllInOnePlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

public class AuctionManager {
    
    private final AllInOnePlugin plugin;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
    
    public AuctionManager(AllInOnePlugin plugin) {
        this.plugin = plugin;
        startAuctionCleaner();
    }
    
    public void openAuctionHouse(Player player) {
        Inventory ah = Bukkit.createInventory(null, 54, ChatColor.DARK_PURPLE + "▸ Casa de Subastas");
        
        // Botones de navegación
        addNavigationButtons(ah);
        
        // Cargar items en subasta
        loadAuctionItems(ah, player, 0);
        
        player.openInventory(ah);
    }
    
    private void addNavigationButtons(Inventory inventory) {
        // Botón de vender
        ItemStack sellButton = new ItemStack(Material.EMERALD);
        ItemMeta sellMeta = sellButton.getItemMeta();
        sellMeta.setDisplayName(ChatColor.GREEN + "🏷️ Vender Item");
        sellMeta.setLore(Arrays.asList(
            ChatColor.GRAY + "Pon un item en subasta",
            "",
            ChatColor.YELLOW + "Comando: /ah sell <precio> [cantidad]",
            ChatColor.GRAY + "Ejemplo: /ah sell 1000 32"
        ));
        sellButton.setItemMeta(sellMeta);
        inventory.setItem(49, sellButton);
        
        // Botón de mis subastas
        ItemStack myAuctions = new ItemStack(Material.CHEST);
        ItemMeta myMeta = myAuctions.getItemMeta();
        myMeta.setDisplayName(ChatColor.GOLD + "📦 Mis Subastas");
        myMeta.setLore(Arrays.asList(
            ChatColor.GRAY + "Ver tus items en venta",
            "",
            ChatColor.GREEN + "Click para ver"
        ));
        myAuctions.setItemMeta(myMeta);
        inventory.setItem(48, myAuctions);
        
        // Botón de items expirados
        ItemStack expired = new ItemStack(Material.HOPPER);
        ItemMeta expiredMeta = expired.getItemMeta();
        expiredMeta.setDisplayName(ChatColor.RED + "⏰ Items Expirados");
        expiredMeta.setLore(Arrays.asList(
            ChatColor.GRAY + "Recuperar items no vendidos",
            "",
            ChatColor.YELLOW + "Click para ver"
        ));
        expired.setItemMeta(expiredMeta);
        inventory.setItem(50, expired);
        
        // Separadores
        ItemStack separator = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta sepMeta = separator.getItemMeta();
        sepMeta.setDisplayName(" ");
        separator.setItemMeta(sepMeta);
        
        for (int i = 45; i < 54; i++) {
            if (i != 48 && i != 49 && i != 50) {
                inventory.setItem(i, separator);
            }
        }
    }
    
    private void loadAuctionItems(Inventory inventory, Player viewer, int page) {
        try {
            ResultSet rs = plugin.getDatabaseManager().executeQuery(
                "SELECT * FROM auctions WHERE active = 1 AND end_time > ? ORDER BY id DESC LIMIT 45 OFFSET ?",
                System.currentTimeMillis(), page * 45);
            
            int slot = 0;
            while (rs.next() && slot < 45) {
                ItemStack auctionItem = createAuctionDisplay(rs, viewer);
                if (auctionItem != null) {
                    inventory.setItem(slot, auctionItem);
                    slot++;
                }
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private ItemStack createAuctionDisplay(ResultSet rs, Player viewer) {
        try {
            String itemData = rs.getString("item_data");
            double price = rs.getDouble("current_bid");
            String sellerUUID = rs.getString("seller_uuid");
            long endTime = rs.getLong("end_time");
            
            // Deserializar item (simplificado)
            ItemStack item = deserializeItem(itemData);
            if (item == null) return null;
            
            ItemMeta meta = item.getItemMeta();
            List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
            
            // Añadir información de subasta
            lore.add("");
            lore.add(ChatColor.GOLD + "💰 Precio: " + ChatColor.GREEN + "$" + String.format("%.2f", price));
            lore.add(ChatColor.GRAY + "👤 Vendedor: " + getPlayerName(sellerUUID));
            lore.add(ChatColor.AQUA + "⏰ Expira: " + dateFormat.format(new Date(endTime)));
            lore.add("");
            
            if (sellerUUID.equals(viewer.getUniqueId().toString())) {
                lore.add(ChatColor.YELLOW + "📝 Tu item en venta");
                lore.add(ChatColor.RED + "Click derecho para cancelar");
            } else {
                lore.add(ChatColor.GREEN + "Click izquierdo para comprar");
                lore.add(ChatColor.BLUE + "Click derecho para ofertar");
            }
            
            meta.setLore(lore);
            item.setItemMeta(meta);
            
            return item;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public boolean sellItem(Player player, ItemStack item, double price, int amount) {
        if (item == null || item.getType() == Material.AIR) {
            player.sendMessage(ChatColor.RED + "Debes tener un item en tu mano!");
            return false;
        }
        
        if (price < 1) {
            player.sendMessage(ChatColor.RED + "El precio mínimo es $1!");
            return false;
        }
        
        if (price > 1000000) {
            player.sendMessage(ChatColor.RED + "El precio máximo es $1,000,000!");
            return false;
        }
        
        if (amount > item.getAmount()) {
            player.sendMessage(ChatColor.RED + "No tienes suficientes items!");
            return false;
        }
        
        // Crear copia del item para vender
        ItemStack sellItem = item.clone();
        sellItem.setAmount(amount);
        
        // Remover del inventario
        if (item.getAmount() == amount) {
            player.getInventory().setItemInMainHand(null);
        } else {
            item.setAmount(item.getAmount() - amount);
        }
        
        // Añadir a base de datos
        try {
            String itemData = serializeItem(sellItem);
            long endTime = System.currentTimeMillis() + (7 * 24 * 60 * 60 * 1000L); // 7 días
            
            plugin.getDatabaseManager().executeUpdate(
                "INSERT INTO auctions (seller_uuid, item_data, starting_price, current_bid, end_time) VALUES (?, ?, ?, ?, ?)",
                player.getUniqueId().toString(), itemData, price, price, endTime);
            
            player.sendMessage(ChatColor.GREEN + "✅ Item puesto en venta por $" + String.format("%.2f", price));
            player.sendMessage(ChatColor.GRAY + "Expira en 7 días");
            
            return true;
            
        } catch (SQLException e) {
            e.printStackTrace();
            player.sendMessage(ChatColor.RED + "Error al poner el item en venta!");
            return false;
        }
    }
    
    public boolean buyItem(Player buyer, int auctionId) {
        try {
            ResultSet rs = plugin.getDatabaseManager().executeQuery(
                "SELECT * FROM auctions WHERE id = ? AND active = 1", auctionId);
            
            if (!rs.next()) {
                buyer.sendMessage(ChatColor.RED + "Subasta no encontrada!");
                return false;
            }
            
            String sellerUUID = rs.getString("seller_uuid");
            double price = rs.getDouble("current_bid");
            String itemData = rs.getString("item_data");
            
            if (sellerUUID.equals(buyer.getUniqueId().toString())) {
                buyer.sendMessage(ChatColor.RED + "No puedes comprar tu propio item!");
                return false;
            }
            
            if (!plugin.getEconomyManager().removeBalance(buyer.getUniqueId(), price)) {
                buyer.sendMessage(ChatColor.RED + "No tienes suficiente dinero!");
                return false;
            }
            
            // Dar dinero al vendedor
            plugin.getEconomyManager().addBalance(UUID.fromString(sellerUUID), price * 0.95); // 5% comisión
            
            // Dar item al comprador
            ItemStack item = deserializeItem(itemData);
            buyer.getInventory().addItem(item);
            
            // Marcar como vendido
            plugin.getDatabaseManager().executeUpdate(
                "UPDATE auctions SET active = 0, bidder_uuid = ? WHERE id = ?",
                buyer.getUniqueId().toString(), auctionId);
            
            buyer.sendMessage(ChatColor.GREEN + "✅ Item comprado por $" + String.format("%.2f", price));
            
            // Notificar al vendedor si está online
            Player seller = Bukkit.getPlayer(UUID.fromString(sellerUUID));
            if (seller != null) {
                seller.sendMessage(ChatColor.GREEN + "💰 " + buyer.getName() + " compró tu item por $" + String.format("%.2f", price));
            }
            
            return true;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    private void startAuctionCleaner() {
        new BukkitRunnable() {
            @Override
            public void run() {
                try {
                    // Marcar subastas expiradas como inactivas
                    plugin.getDatabaseManager().executeUpdate(
                        "UPDATE auctions SET active = 0 WHERE end_time < ? AND active = 1",
                        System.currentTimeMillis());
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }.runTaskTimer(plugin, 20L * 60, 20L * 60); // Cada minuto
    }
    
    private String serializeItem(ItemStack item) {
        // Implementación simplificada - en producción usar Base64
        return item.getType().name() + ":" + item.getAmount();
    }
    
    private ItemStack deserializeItem(String data) {
        try {
            String[] parts = data.split(":");
            Material material = Material.valueOf(parts[0]);
            int amount = Integer.parseInt(parts[1]);
            return new ItemStack(material, amount);
        } catch (Exception e) {
            return new ItemStack(Material.STONE);
        }
    }
    
    private String getPlayerName(String uuid) {
        try {
            Player player = Bukkit.getPlayer(UUID.fromString(uuid));
            return player != null ? player.getName() : "Jugador";
        } catch (Exception e) {
            return "Desconocido";
        }
    }
}