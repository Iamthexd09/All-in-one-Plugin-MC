package com.allinone.managers;

import com.allinone.AllInOnePlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class KitManager {
    
    private final AllInOnePlugin plugin;
    private final Map<String, Kit> kits = new HashMap<>();
    
    public KitManager(AllInOnePlugin plugin) {
        this.plugin = plugin;
        loadKits();
    }
    
    private void loadKits() {
        // Kit Starter
        Kit starter = new Kit("starter", "allinone.kit.starter", 86400, // 24 horas
            new ItemStack[]{
                new ItemStack(Material.WOODEN_SWORD),
                new ItemStack(Material.WOODEN_PICKAXE),
                new ItemStack(Material.BREAD, 10),
                new ItemStack(Material.LEATHER_HELMET),
                new ItemStack(Material.LEATHER_CHESTPLATE),
                new ItemStack(Material.LEATHER_LEGGINGS),
                new ItemStack(Material.LEATHER_BOOTS)
            });
        
        // Kit VIP
        Kit vip = new Kit("vip", "allinone.kit.vip", 43200, // 12 horas
            new ItemStack[]{
                new ItemStack(Material.IRON_SWORD),
                new ItemStack(Material.IRON_PICKAXE),
                new ItemStack(Material.COOKED_BEEF, 16),
                new ItemStack(Material.IRON_HELMET),
                new ItemStack(Material.IRON_CHESTPLATE),
                new ItemStack(Material.IRON_LEGGINGS),
                new ItemStack(Material.IRON_BOOTS),
                new ItemStack(Material.GOLDEN_APPLE, 3)
            });
        
        // Kit Premium
        Kit premium = new Kit("premium", "allinone.kit.premium", 21600, // 6 horas
            new ItemStack[]{
                new ItemStack(Material.DIAMOND_SWORD),
                new ItemStack(Material.DIAMOND_PICKAXE),
                new ItemStack(Material.COOKED_BEEF, 32),
                new ItemStack(Material.DIAMOND_HELMET),
                new ItemStack(Material.DIAMOND_CHESTPLATE),
                new ItemStack(Material.DIAMOND_LEGGINGS),
                new ItemStack(Material.DIAMOND_BOOTS),
                new ItemStack(Material.GOLDEN_APPLE, 5),
                new ItemStack(Material.ENDER_PEARL, 8)
            });
        
        // Kit PvP
        Kit pvp = new Kit("pvp", "allinone.kit.pvp", 3600, // 1 hora
            new ItemStack[]{
                new ItemStack(Material.NETHERITE_SWORD),
                new ItemStack(Material.BOW),
                new ItemStack(Material.ARROW, 64),
                new ItemStack(Material.NETHERITE_HELMET),
                new ItemStack(Material.NETHERITE_CHESTPLATE),
                new ItemStack(Material.NETHERITE_LEGGINGS),
                new ItemStack(Material.NETHERITE_BOOTS),
                new ItemStack(Material.GOLDEN_APPLE, 10),
                new ItemStack(Material.TOTEM_OF_UNDYING, 2)
            });
        
        kits.put("starter", starter);
        kits.put("vip", vip);
        kits.put("premium", premium);
        kits.put("pvp", pvp);
    }
    
    public void openKitGUI(Player player) {
        Inventory kitGUI = Bukkit.createInventory(null, 27, ChatColor.DARK_PURPLE + "▸ Kits Disponibles");
        
        int slot = 0;
        for (Kit kit : kits.values()) {
            ItemStack icon = createKitIcon(player, kit);
            kitGUI.setItem(slot, icon);
            slot++;
        }
        
        player.openInventory(kitGUI);
    }
    
    private ItemStack createKitIcon(Player player, Kit kit) {
        Material iconMaterial = getKitIconMaterial(kit.getName());
        ItemStack icon = new ItemStack(iconMaterial);
        ItemMeta meta = icon.getItemMeta();
        
        boolean canUse = canUseKit(player, kit.getName());
        long cooldownLeft = getCooldownLeft(player.getUniqueId(), kit.getName());
        
        if (canUse) {
            meta.setDisplayName(ChatColor.GREEN + "✓ Kit " + kit.getName().toUpperCase());
        } else {
            meta.setDisplayName(ChatColor.RED + "✗ Kit " + kit.getName().toUpperCase());
        }
        
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Permiso: " + ChatColor.YELLOW + kit.getPermission(),
            ChatColor.GRAY + "Cooldown: " + ChatColor.AQUA + formatTime(kit.getCooldown()),
            "",
            canUse ? 
                ChatColor.GREEN + "¡Click para obtener!" :
                ChatColor.RED + "Disponible en: " + ChatColor.YELLOW + formatTime(cooldownLeft),
            "",
            ChatColor.GRAY + "Contenido:",
            getKitPreview(kit)
        ));
        
        icon.setItemMeta(meta);
        return icon;
    }
    
    private Material getKitIconMaterial(String kitName) {
        switch (kitName.toLowerCase()) {
            case "starter": return Material.WOODEN_SWORD;
            case "vip": return Material.IRON_SWORD;
            case "premium": return Material.DIAMOND_SWORD;
            case "pvp": return Material.NETHERITE_SWORD;
            default: return Material.CHEST;
        }
    }
    
    private String getKitPreview(Kit kit) {
        StringBuilder preview = new StringBuilder();
        ItemStack[] items = kit.getItems();
        int count = 0;
        
        for (ItemStack item : items) {
            if (item != null && count < 3) {
                preview.append(ChatColor.GRAY).append("• ")
                       .append(item.getAmount()).append("x ")
                       .append(item.getType().name().replace("_", " "));
                if (count < 2 && count < items.length - 1) preview.append("\n");
                count++;
            }
        }
        
        if (items.length > 3) {
            preview.append(ChatColor.GRAY).append("\n• Y ").append(items.length - 3).append(" items más...");
        }
        
        return preview.toString();
    }
    
    public boolean giveKit(Player player, String kitName) {
        Kit kit = kits.get(kitName.toLowerCase());
        if (kit == null) return false;
        
        if (!player.hasPermission(kit.getPermission())) {
            player.sendMessage(ChatColor.RED + "No tienes permisos para usar este kit!");
            return false;
        }
        
        if (!canUseKit(player, kitName)) {
            long cooldownLeft = getCooldownLeft(player.getUniqueId(), kitName);
            player.sendMessage(ChatColor.RED + "Debes esperar " + formatTime(cooldownLeft) + " para usar este kit!");
            return false;
        }
        
        // Dar items
        for (ItemStack item : kit.getItems()) {
            if (item != null) {
                player.getInventory().addItem(item.clone());
            }
        }
        
        // Actualizar cooldown
        updateKitUsage(player.getUniqueId(), kitName);
        
        player.sendMessage(ChatColor.GREEN + "¡Has recibido el kit " + kitName.toUpperCase() + "!");
        return true;
    }
    
    private boolean canUseKit(Player player, String kitName) {
        Kit kit = kits.get(kitName.toLowerCase());
        if (kit == null) return false;
        
        if (!player.hasPermission(kit.getPermission())) return false;
        
        return getCooldownLeft(player.getUniqueId(), kitName) <= 0;
    }
    
    private long getCooldownLeft(UUID playerUUID, String kitName) {
        try {
            ResultSet rs = plugin.getDatabaseManager().executeQuery(
                "SELECT last_used FROM kit_usage WHERE uuid = ? AND kit_name = ?",
                playerUUID.toString(), kitName);
            
            if (rs.next()) {
                long lastUsed = rs.getLong("last_used");
                Kit kit = kits.get(kitName.toLowerCase());
                if (kit != null) {
                    long cooldownEnd = lastUsed + (kit.getCooldown() * 1000L);
                    return Math.max(0, cooldownEnd - System.currentTimeMillis());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    private void updateKitUsage(UUID playerUUID, String kitName) {
        try {
            plugin.getDatabaseManager().executeUpdate(
                "INSERT OR REPLACE INTO kit_usage (uuid, kit_name, last_used) VALUES (?, ?, ?)",
                playerUUID.toString(), kitName, System.currentTimeMillis());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private String formatTime(long milliseconds) {
        if (milliseconds <= 0) return "0s";
        
        long seconds = milliseconds / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;
        
        if (days > 0) return days + "d " + (hours % 24) + "h";
        if (hours > 0) return hours + "h " + (minutes % 60) + "m";
        if (minutes > 0) return minutes + "m " + (seconds % 60) + "s";
        return seconds + "s";
    }
    
    // Clase interna Kit
    private static class Kit {
        private final String name;
        private final String permission;
        private final long cooldown;
        private final ItemStack[] items;
        
        public Kit(String name, String permission, long cooldown, ItemStack[] items) {
            this.name = name;
            this.permission = permission;
            this.cooldown = cooldown;
            this.items = items;
        }
        
        public String getName() { return name; }
        public String getPermission() { return permission; }
        public long getCooldown() { return cooldown; }
        public ItemStack[] getItems() { return items; }
    }
}