package com.allinone.managers;

import com.allinone.AllInOnePlugin;
import org.bukkit.entity.Player;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

public class EconomyManager {
    
    private final AllInOnePlugin plugin;
    
    public EconomyManager(AllInOnePlugin plugin) {
        this.plugin = plugin;
    }
    
    public double getBalance(UUID playerUUID) {
        try {
            ResultSet rs = plugin.getDatabaseManager().executeQuery(
                "SELECT balance FROM economy WHERE uuid = ?", playerUUID.toString());
            
            if (rs.next()) {
                return rs.getDouble("balance");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        // Si no existe, crear con balance inicial
        setBalance(playerUUID, 1000.0);
        return 1000.0;
    }
    
    public void setBalance(UUID playerUUID, double amount) {
        try {
            plugin.getDatabaseManager().executeUpdate(
                "INSERT OR REPLACE INTO economy (uuid, balance) VALUES (?, ?)",
                playerUUID.toString(), amount);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public boolean addBalance(UUID playerUUID, double amount) {
        if (amount <= 0) return false;
        
        double currentBalance = getBalance(playerUUID);
        setBalance(playerUUID, currentBalance + amount);
        return true;
    }
    
    public boolean removeBalance(UUID playerUUID, double amount) {
        if (amount <= 0) return false;
        
        double currentBalance = getBalance(playerUUID);
        if (currentBalance < amount) return false;
        
        setBalance(playerUUID, currentBalance - amount);
        return true;
    }
    
    public boolean transferMoney(UUID from, UUID to, double amount) {
        if (amount <= 0) return false;
        if (getBalance(from) < amount) return false;
        
        removeBalance(from, amount);
        addBalance(to, amount);
        return true;
    }
    
    public String formatMoney(double amount) {
        return String.format("$%.2f", amount);
    }
}