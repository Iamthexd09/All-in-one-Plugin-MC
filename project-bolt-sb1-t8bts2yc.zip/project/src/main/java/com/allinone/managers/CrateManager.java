package com.allinone.managers;

import com.allinone.AllInOnePlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class CrateManager {
    
    private final AllInOnePlugin plugin;
    private final Random random = new Random();
    private final Map<String, CrateType> crateTypes = new HashMap<>();
    
    public CrateManager(AllInOnePlugin plugin) {
        this.plugin = plugin;
        initializeCrateTypes();
    }
    
    private void initializeCrateTypes() {
        // Crate Básico
        CrateType basic = new CrateType("basico", 100, Material.CHEST,
            new CrateReward[]{
                new CrateReward(new ItemStack(Material.IRON_INGOT, 5), 30, "Común"),
                new CrateReward(new ItemStack(Material.GOLD_INGOT, 3), 25, "Común"),
                new CrateReward(new ItemStack(Material.DIAMOND, 1), 20, "Raro"),
                new CrateReward(new ItemStack(Material.EMERALD, 2), 15, "Raro"),
                new CrateReward(new ItemStack(Material.COOKED_BEEF, 16), 10, "Épico")
            });
        
        // Crate Premium
        CrateType premium = new CrateType("premium", 500, Material.ENDER_CHEST,
            new CrateReward[]{
                new CrateReward(createEnchantedItem(Material.DIAMOND_SWORD, "Espada Mágica"), 25, "Épico"),
                new CrateReward(createEnchantedItem(Material.DIAMOND_PICKAXE, "Pico Mágico"), 20, "Épico"),
                new CrateReward(new ItemStack(Material.DIAMOND, 5), 20, "Raro"),
                new CrateReward(new ItemStack(Material.EMERALD, 8), 15, "Raro"),
                new CrateReward(new ItemStack(Material.GOLDEN_APPLE, 3), 15, "Épico"),
                new CrateReward(new ItemStack(Material.TOTEM_OF_UNDYING, 1), 5, "Legendario")
            });
        
        // Crate Legendario
        CrateType legendary = new CrateType("legendario", 2000, Material.SHULKER_BOX,
            new CrateReward[]{
                new CrateReward(createEnchantedItem(Material.NETHERITE_SWORD, "Espada Legendaria"), 20, "Legendario"),
                new CrateReward(createEnchantedItem(Material.NETHERITE_PICKAXE, "Pico Legendario"), 15, "Legendario"),
                new CrateReward(new ItemStack(Material.NETHERITE_INGOT, 3), 15, "Épico"),
                new CrateReward(new ItemStack(Material.DIAMOND, 16), 20, "Épico"),
                new CrateReward(new ItemStack(Material.ENCHANTED_GOLDEN_APPLE, 1), 10, "Mítico"),
                new CrateReward(new ItemStack(Material.DRAGON_EGG, 1), 1, "Mítico"),
                new CrateReward(createCustomEnchantedItem(), 19, "Legendario")
            });
        
        crateTypes.put("basico", basic);
        crateTypes.put("premium", premium);
        crateTypes.put("legendario", legendary);
    }
    
    public void openCrateGUI(Player player) {
        Inventory crateGUI = Bukkit.createInventory(null, 27, ChatColor.DARK_PURPLE + "▸ Crates Disponibles");
        
        int slot = 10;
        for (CrateType crate : crateTypes.values()) {
            ItemStack icon = createCrateIcon(crate);
            crateGUI.setItem(slot, icon);
            slot += 2;
        }
        
        player.openInventory(crateGUI);
    }
    
    private ItemStack createCrateIcon(CrateType crate) {
        ItemStack icon = new ItemStack(crate.getIcon());
        ItemMeta meta = icon.getItemMeta();
        
        meta.setDisplayName(ChatColor.GOLD + "Crate " + crate.getName().toUpperCase());
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Precio: " + ChatColor.GREEN + "$" + crate.getPrice(),
            "",
            ChatColor.YELLOW + "Recompensas posibles:",
            getRewardPreview(crate),
            "",
            ChatColor.GREEN + "¡Click para abrir!"
        ));
        
        icon.setItemMeta(meta);
        return icon;
    }
    
    private String getRewardPreview(CrateType crate) {
        StringBuilder preview = new StringBuilder();
        CrateReward[] rewards = crate.getRewards();
        
        for (int i = 0; i < Math.min(3, rewards.length); i++) {
            CrateReward reward = rewards[i];
            ChatColor rarityColor = getRarityColor(reward.getRarity());
            preview.append(rarityColor).append("• ").append(reward.getRarity())
                   .append(" - ").append(reward.getChance()).append("%");
            if (i < Math.min(2, rewards.length - 1)) preview.append("\n");
        }
        
        if (rewards.length > 3) {
            preview.append(ChatColor.GRAY).append("\n• Y más recompensas...");
        }
        
        return preview.toString();
    }
    
    public boolean openCrate(Player player, String crateTypeName) {
        CrateType crate = crateTypes.get(crateTypeName.toLowerCase());
        if (crate == null) return false;
        
        // Verificar dinero
        if (!plugin.getEconomyManager().removeBalance(player.getUniqueId(), crate.getPrice())) {
            player.sendMessage(ChatColor.RED + "No tienes suficiente dinero! Necesitas $" + crate.getPrice());
            return false;
        }
        
        // Animación de apertura
        startCrateAnimation(player, crate);
        return true;
    }
    
    private void startCrateAnimation(Player player, CrateType crate) {
        Inventory animationGUI = Bukkit.createInventory(null, 27, 
            ChatColor.GOLD + "Abriendo " + crate.getName().toUpperCase() + "...");
        
        // Llenar con items aleatorios para la animación
        for (int i = 0; i < 27; i++) {
            if (i != 13) { // Slot central
                animationGUI.setItem(i, createRandomAnimationItem());
            }
        }
        
        player.openInventory(animationGUI);
        player.playSound(player.getLocation(), Sound.BLOCK_CHEST_OPEN, 1.0f, 1.0f);
        
        // Animación de spinning
        new BukkitRunnable() {
            int ticks = 0;
            final int maxTicks = 60; // 3 segundos
            
            @Override
            public void run() {
                if (ticks >= maxTicks) {
                    // Mostrar resultado final
                    CrateReward reward = selectRandomReward(crate);
                    showFinalReward(player, crate, reward, animationGUI);
                    cancel();
                    return;
                }
                
                // Actualizar animación
                if (ticks % 3 == 0) { // Cada 3 ticks
                    for (int i = 0; i < 27; i++) {
                        if (i != 13) {
                            animationGUI.setItem(i, createRandomAnimationItem());
                        }
                    }
                    player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1.5f);
                }
                
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }
    
    private void showFinalReward(Player player, CrateType crate, CrateReward reward, Inventory gui) {
        // Limpiar GUI
        gui.clear();
        
        // Mostrar recompensa en el centro
        ItemStack rewardItem = reward.getItem().clone();
        ItemMeta meta = rewardItem.getItemMeta();
        
        ChatColor rarityColor = getRarityColor(reward.getRarity());
        meta.setDisplayName(rarityColor + "¡RECOMPENSA OBTENIDA!");
        meta.setLore(Arrays.asList(
            "",
            rarityColor + "Rareza: " + reward.getRarity(),
            ChatColor.GRAY + "Probabilidad: " + reward.getChance() + "%",
            "",
            ChatColor.GREEN + "¡Añadido a tu inventario!"
        ));
        
        rewardItem.setItemMeta(meta);
        gui.setItem(13, rewardItem);
        
        // Efectos
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        
        // Dar recompensa al jugador
        player.getInventory().addItem(reward.getItem().clone());
        
        // Mensaje de chat
        String rewardName = reward.getItem().hasItemMeta() && reward.getItem().getItemMeta().hasDisplayName() ?
                           reward.getItem().getItemMeta().getDisplayName() :
                           reward.getItem().getAmount() + "x " + reward.getItem().getType().name().replace("_", " ");
        
        player.sendMessage(ChatColor.GOLD + "¡Has obtenido: " + rarityColor + rewardName + ChatColor.GOLD + "!");
        
        // Anunciar recompensas míticas/legendarias
        if (reward.getRarity().equals("Mítico") || reward.getRarity().equals("Legendario")) {
            plugin.getServer().broadcastMessage(
                ChatColor.GOLD + "¡" + player.getName() + " ha obtenido " + 
                rarityColor + rewardName + ChatColor.GOLD + " de un crate " + 
                crate.getName() + "!");
        }
        
        // Cerrar GUI después de 3 segundos
        new BukkitRunnable() {
            @Override
            public void run() {
                player.closeInventory();
            }
        }.runTaskLater(plugin, 60L);
    }
    
    private CrateReward selectRandomReward(CrateType crate) {
        int totalWeight = 0;
        for (CrateReward reward : crate.getRewards()) {
            totalWeight += reward.getChance();
        }
        
        int randomValue = random.nextInt(totalWeight);
        int currentWeight = 0;
        
        for (CrateReward reward : crate.getRewards()) {
            currentWeight += reward.getChance();
            if (randomValue < currentWeight) {
                return reward;
            }
        }
        
        return crate.getRewards()[0]; // Fallback
    }
    
    private ItemStack createRandomAnimationItem() {
        Material[] materials = {
            Material.DIAMOND, Material.EMERALD, Material.GOLD_INGOT,
            Material.IRON_INGOT, Material.COAL, Material.REDSTONE
        };
        return new ItemStack(materials[random.nextInt(materials.length)]);
    }
    
    private ItemStack createEnchantedItem(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.LIGHT_PURPLE + name);
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Objeto mágico del crate",
            ChatColor.GOLD + "¡Muy poderoso!"
        ));
        item.setItemMeta(meta);
        return item;
    }
    
    private ItemStack createCustomEnchantedItem() {
        ItemStack item = new ItemStack(Material.ENCHANTED_BOOK);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.DARK_PURPLE + "Libro de Encantamiento Custom");
        meta.setLore(Arrays.asList(
            ChatColor.GRAY + "Contiene encantamientos únicos",
            ChatColor.GOLD + "¡Muy raro!",
            "",
            ChatColor.AQUA + "• Lightning (Rayo)",
            ChatColor.AQUA + "• Explosive (Explosivo)",
            ChatColor.AQUA + "• Vampire (Vampiro)"
        ));
        item.setItemMeta(meta);
        return item;
    }
    
    private ChatColor getRarityColor(String rarity) {
        switch (rarity.toLowerCase()) {
            case "común": return ChatColor.WHITE;
            case "raro": return ChatColor.BLUE;
            case "épico": return ChatColor.DARK_PURPLE;
            case "legendario": return ChatColor.GOLD;
            case "mítico": return ChatColor.RED;
            default: return ChatColor.GRAY;
        }
    }
    
    // Clases internas
    private static class CrateType {
        private final String name;
        private final double price;
        private final Material icon;
        private final CrateReward[] rewards;
        
        public CrateType(String name, double price, Material icon, CrateReward[] rewards) {
            this.name = name;
            this.price = price;
            this.icon = icon;
            this.rewards = rewards;
        }
        
        public String getName() { return name; }
        public double getPrice() { return price; }
        public Material getIcon() { return icon; }
        public CrateReward[] getRewards() { return rewards; }
    }
    
    private static class CrateReward {
        private final ItemStack item;
        private final int chance;
        private final String rarity;
        
        public CrateReward(ItemStack item, int chance, String rarity) {
            this.item = item;
            this.chance = chance;
            this.rarity = rarity;
        }
        
        public ItemStack getItem() { return item; }
        public int getChance() { return chance; }
        public String getRarity() { return rarity; }
    }
}