package com.allinone.managers;

import com.allinone.AllInOnePlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class HomeManager {
    
    private final AllInOnePlugin plugin;
    
    public HomeManager(AllInOnePlugin plugin) {
        this.plugin = plugin;
    }
    
    public boolean setHome(Player player, String homeName) {
        try {
            Location loc = player.getLocation();
            
            // Verificar si ya existe
            plugin.getDatabaseManager().executeUpdate(
                "DELETE FROM homes WHERE uuid = ? AND name = ?",
                player.getUniqueId().toString(), homeName);
            
            // Insertar nuevo home
            plugin.getDatabaseManager().executeUpdate(
                "INSERT INTO homes (uuid, name, world, x, y, z, yaw, pitch) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                player.getUniqueId().toString(), homeName, loc.getWorld().getName(),
                loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), loc.getPitch());
            
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean teleportToHome(Player player, String homeName) {
        try {
            ResultSet rs = plugin.getDatabaseManager().executeQuery(
                "SELECT * FROM homes WHERE uuid = ? AND name = ?",
                player.getUniqueId().toString(), homeName);
            
            if (rs.next()) {
                World world = Bukkit.getWorld(rs.getString("world"));
                if (world != null) {
                    Location loc = new Location(world,
                        rs.getDouble("x"), rs.getDouble("y"), rs.getDouble("z"),
                        rs.getFloat("yaw"), rs.getFloat("pitch"));
                    
                    player.teleport(loc);
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public List<String> getPlayerHomes(UUID playerUUID) {
        List<String> homes = new ArrayList<>();
        try {
            ResultSet rs = plugin.getDatabaseManager().executeQuery(
                "SELECT name FROM homes WHERE uuid = ?", playerUUID.toString());
            
            while (rs.next()) {
                homes.add(rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return homes;
    }
}