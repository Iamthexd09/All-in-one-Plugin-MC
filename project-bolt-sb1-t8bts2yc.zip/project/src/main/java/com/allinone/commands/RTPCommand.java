package com.allinone.commands;

import com.allinone.AllInOnePlugin;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Random;

public class RTPCommand implements CommandExecutor {
    
    private final AllInOnePlugin plugin;
    private final Random random = new Random();
    
    public RTPCommand(AllInOnePlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Solo los jugadores pueden usar este comando!");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (!player.hasPermission("allinone.rtp")) {
            player.sendMessage(ChatColor.RED + "No tienes permisos para usar este comando!");
            return true;
        }
        
        player.sendMessage(ChatColor.YELLOW + "Buscando ubicación segura...");
        
        // Buscar ubicación aleatoria
        Location randomLocation = findSafeLocation(player.getWorld());
        
        if (randomLocation != null) {
            player.teleport(randomLocation);
            player.sendMessage(ChatColor.GREEN + "¡Te has teletransportado aleatoriamente!");
            player.sendMessage(ChatColor.GRAY + "Coordenadas: " + 
                randomLocation.getBlockX() + ", " + 
                randomLocation.getBlockY() + ", " + 
                randomLocation.getBlockZ());
        } else {
            player.sendMessage(ChatColor.RED + "No se pudo encontrar una ubicación segura!");
        }
        
        return true;
    }
    
    private Location findSafeLocation(World world) {
        int maxAttempts = 10;
        int minDistance = 1000;
        int maxDistance = 5000;
        
        for (int i = 0; i < maxAttempts; i++) {
            int x = random.nextInt(maxDistance - minDistance) + minDistance;
            int z = random.nextInt(maxDistance - minDistance) + minDistance;
            
            // 50% de probabilidad de coordenadas negativas
            if (random.nextBoolean()) x = -x;
            if (random.nextBoolean()) z = -z;
            
            int y = world.getHighestBlockYAt(x, z) + 1;
            Location location = new Location(world, x + 0.5, y, z + 0.5);
            
            if (isSafeLocation(location)) {
                return location;
            }
        }
        
        return null;
    }
    
    private boolean isSafeLocation(Location location) {
        // Verificar que el bloque de abajo no sea líquido o aire
        Material groundBlock = location.getBlock().getRelative(0, -1, 0).getType();
        if (groundBlock == Material.WATER || groundBlock == Material.LAVA || groundBlock == Material.AIR) {
            return false;
        }
        
        // Verificar que haya espacio para el jugador
        Material blockAtFeet = location.getBlock().getType();
        Material blockAtHead = location.getBlock().getRelative(0, 1, 0).getType();
        
        return blockAtFeet == Material.AIR && blockAtHead == Material.AIR;
    }
}