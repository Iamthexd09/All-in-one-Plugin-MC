package com.allinone.commands;

import com.allinone.AllInOnePlugin;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KitCommand implements CommandExecutor {
    
    private final AllInOnePlugin plugin;
    
    public KitCommand(AllInOnePlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Solo los jugadores pueden usar este comando!");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (!player.hasPermission("allinone.kit")) {
            player.sendMessage(ChatColor.RED + "No tienes permisos para usar este comando!");
            return true;
        }
        
        if (args.length == 0) {
            // Abrir GUI de kits
            plugin.getKitManager().openKitGUI(player);
            return true;
        }
        
        String kitName = args[0];
        if (plugin.getKitManager().giveKit(player, kitName)) {
            // Éxito - mensaje ya enviado por el manager
        } else {
            player.sendMessage(ChatColor.RED + "Kit no encontrado! Usa /kit para ver los disponibles.");
        }
        
        return true;
    }
}