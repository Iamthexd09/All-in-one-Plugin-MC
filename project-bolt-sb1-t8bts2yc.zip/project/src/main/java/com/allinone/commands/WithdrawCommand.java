package com.allinone.commands;

import com.allinone.AllInOnePlugin;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class WithdrawCommand implements CommandExecutor {
    
    private final AllInOnePlugin plugin;
    
    public WithdrawCommand(AllInOnePlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Solo los jugadores pueden usar este comando!");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (!player.hasPermission("allinone.withdraw")) {
            player.sendMessage(ChatColor.RED + "No tienes permisos para usar este comando!");
            return true;
        }
        
        if (args.length != 1) {
            player.sendMessage(ChatColor.RED + "Uso: /withdraw <cantidad>");
            player.sendMessage(ChatColor.GRAY + "Ejemplo: /withdraw 100");
            return true;
        }
        
        try {
            double amount = Double.parseDouble(args[0]);
            
            if (amount <= 0) {
                player.sendMessage(ChatColor.RED + "La cantidad debe ser mayor a 0!");
                return true;
            }
            
            if (amount > 1000000) {
                player.sendMessage(ChatColor.RED + "No puedes retirar más de $1,000,000 a la vez!");
                return true;
            }
            
            // Verificar si el jugador tiene suficiente dinero
            double currentBalance = plugin.getEconomyManager().getBalance(player.getUniqueId());
            if (currentBalance < amount) {
                player.sendMessage(ChatColor.RED + "No tienes suficiente dinero!");
                player.sendMessage(ChatColor.GRAY + "Tu saldo: $" + String.format("%.2f", currentBalance));
                return true;
            }
            
            // Verificar espacio en inventario
            if (player.getInventory().firstEmpty() == -1) {
                player.sendMessage(ChatColor.RED + "No tienes espacio en tu inventario!");
                return true;
            }
            
            // Retirar dinero del saldo
            if (plugin.getEconomyManager().removeBalance(player.getUniqueId(), amount)) {
                // Crear billete de dinero
                ItemStack moneyNote = createMoneyNote(amount);
                player.getInventory().addItem(moneyNote);
                
                player.sendMessage(ChatColor.GREEN + "¡Has retirado $" + String.format("%.2f", amount) + " como billete!");
                player.sendMessage(ChatColor.GRAY + "Nuevo saldo: $" + 
                    String.format("%.2f", plugin.getEconomyManager().getBalance(player.getUniqueId())));
                
            } else {
                player.sendMessage(ChatColor.RED + "Error al procesar la transacción!");
            }
            
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "Cantidad inválida! Usa solo números.");
            player.sendMessage(ChatColor.GRAY + "Ejemplo: /withdraw 100");
        }
        
        return true;
    }
    
    private ItemStack createMoneyNote(double amount) {
        ItemStack note = new ItemStack(Material.PAPER);
        ItemMeta meta = note.getItemMeta();
        
        // Determinar el tipo de billete según la cantidad
        String noteType;
        ChatColor noteColor;
        
        if (amount >= 10000) {
            noteType = "Billete Diamante";
            noteColor = ChatColor.AQUA;
        } else if (amount >= 1000) {
            noteType = "Billete Oro";
            noteColor = ChatColor.GOLD;
        } else if (amount >= 100) {
            noteType = "Billete Plata";
            noteColor = ChatColor.GRAY;
        } else {
            noteType = "Billete Básico";
            noteColor = ChatColor.GREEN;
        }
        
        meta.setDisplayName(noteColor + "💵 " + noteType);
        meta.setLore(Arrays.asList(
            ChatColor.WHITE + "Valor: " + ChatColor.GREEN + "$" + String.format("%.2f", amount),
            "",
            ChatColor.YELLOW + "Click derecho para depositar",
            ChatColor.GRAY + "Este billete representa dinero real",
            "",
            ChatColor.DARK_GRAY + "All-in-one Plugin",
            ChatColor.DARK_GRAY + "ID: " + System.currentTimeMillis()
        ));
        
        note.setItemMeta(meta);
        return note;
    }
    
    public static boolean isMoneyNote(ItemStack item) {
        if (item == null || item.getType() != Material.PAPER) return false;
        if (!item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) return false;
        
        String displayName = item.getItemMeta().getDisplayName();
        return displayName.contains("💵") && displayName.contains("Billete");
    }
    
    public static double getMoneyNoteValue(ItemStack item) {
        if (!isMoneyNote(item)) return 0;
        
        for (String line : item.getItemMeta().getLore()) {
            if (line.contains("Valor: $")) {
                String valueStr = line.replace("Valor: $", "")
                    .replace(ChatColor.WHITE.toString(), "")
                    .replace(ChatColor.GREEN.toString(), "")
                    .trim();
                try {
                    return Double.parseDouble(valueStr);
                } catch (NumberFormatException e) {
                    return 0;
                }
            }
        }
        return 0;
    }
}