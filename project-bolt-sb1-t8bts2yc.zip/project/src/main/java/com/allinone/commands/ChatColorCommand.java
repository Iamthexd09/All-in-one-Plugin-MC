package com.allinone.commands;

import com.allinone.AllInOnePlugin;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ChatColorCommand implements CommandExecutor {
    
    private final AllInOnePlugin plugin;
    
    public ChatColorCommand(AllInOnePlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Solo los jugadores pueden usar este comando!");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (!player.hasPermission("allinone.chatcolor")) {
            player.sendMessage(ChatColor.RED + "No tienes permisos para usar este comando!");
            return true;
        }
        
        if (args.length == 0) {
            player.sendMessage(ChatColor.RED + "Uso: /chatcolor <código>");
            player.sendMessage(ChatColor.GRAY + "Códigos disponibles:");
            player.sendMessage(ChatColor.GRAY + "&0 = Negro, &1 = Azul oscuro, &2 = Verde oscuro");
            player.sendMessage(ChatColor.GRAY + "&3 = Aqua oscuro, &4 = Rojo oscuro, &5 = Púrpura");
            player.sendMessage(ChatColor.GRAY + "&6 = Oro, &7 = Gris, &8 = Gris oscuro");
            player.sendMessage(ChatColor.GRAY + "&9 = Azul, &a = Verde, &b = Aqua");
            player.sendMessage(ChatColor.GRAY + "&c = Rojo, &d = Rosa, &e = Amarillo, &f = Blanco");
            return true;
        }
        
        String colorCode = args[0];
        
        // Validar código de color
        if (!isValidColorCode(colorCode)) {
            player.sendMessage(ChatColor.RED + "Código de color inválido! Usa códigos como &1, &2, &a, &c, etc.");
            return true;
        }
        
        // Obtener nickname actual
        String currentNickname = plugin.getRankManager().getPlayerNickname(player.getUniqueId());
        if (currentNickname == null) {
            currentNickname = player.getName();
        } else {
            // Remover códigos de color existentes del nickname
            currentNickname = ChatColor.stripColor(ChatColor.translateAlternateColorCodes('&', currentNickname));
        }
        
        // Aplicar nuevo color
        plugin.getRankManager().setPlayerNickname(player.getUniqueId(), currentNickname, colorCode);
        
        ChatColor color = ChatColor.getByChar(colorCode.charAt(1));
        player.sendMessage(ChatColor.GREEN + "Tu color de chat ha sido cambiado a: " + color + colorCode);
        
        return true;
    }
    
    private boolean isValidColorCode(String code) {
        if (code.length() != 2 || code.charAt(0) != '&') return false;
        
        char colorChar = code.charAt(1);
        return "0123456789abcdef".indexOf(colorChar) != -1;
    }
}