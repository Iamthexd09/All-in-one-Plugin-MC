package com.allinone.commands;

import com.allinone.AllInOnePlugin;
import com.allinone.managers.HomeManager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HomeCommand implements CommandExecutor {
    
    private final AllInOnePlugin plugin;
    private final HomeManager homeManager;
    
    public HomeCommand(AllInOnePlugin plugin) {
        this.plugin = plugin;
        this.homeManager = plugin.getHomeManager();
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Solo los jugadores pueden usar este comando!");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (!player.hasPermission("allinone.home")) {
            player.sendMessage(ChatColor.RED + "No tienes permisos para usar este comando!");
            return true;
        }
        
        if (label.equalsIgnoreCase("sethome")) {
            String homeName = args.length > 0 ? args[0] : "home";
            
            if (homeManager.setHome(player, homeName)) {
                player.sendMessage(ChatColor.GREEN + "Casa '" + homeName + "' establecida correctamente!");
            } else {
                player.sendMessage(ChatColor.RED + "Error al establecer la casa!");
            }
            
        } else if (label.equalsIgnoreCase("home")) {
            String homeName = args.length > 0 ? args[0] : "home";
            
            if (homeManager.teleportToHome(player, homeName)) {
                player.sendMessage(ChatColor.GREEN + "Te has teletransportado a casa '" + homeName + "'!");
            } else {
                player.sendMessage(ChatColor.RED + "No se encontró la casa '" + homeName + "'!");
            }
        }
        
        return true;
    }
}