package com.allinone.commands;

import com.allinone.AllInOnePlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class EconomyCommand implements CommandExecutor {
    
    private final AllInOnePlugin plugin;
    
    public EconomyCommand(AllInOnePlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Solo los jugadores pueden usar este comando!");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (label.equalsIgnoreCase("money")) {
            double balance = plugin.getEconomyManager().getBalance(player.getUniqueId());
            player.sendMessage(ChatColor.GREEN + "Tu dinero: " + ChatColor.GOLD + "$" + String.format("%.2f", balance));
            return true;
        }
        
        if (label.equalsIgnoreCase("pay")) {
            if (args.length != 2) {
                player.sendMessage(ChatColor.RED + "Uso: /pay <jugador> <cantidad>");
                player.sendMessage(ChatColor.GRAY + "Cantidad mínima: $10");
                return true;
            }
            
            Player target = Bukkit.getPlayer(args[0]);
            if (target == null) {
                player.sendMessage(ChatColor.RED + "El jugador no está en línea!");
                return true;
            }
            
            if (target.equals(player)) {
                player.sendMessage(ChatColor.RED + "No puedes pagarte a ti mismo!");
                return true;
            }
            
            try {
                double amount = Double.parseDouble(args[1]);
                if (amount < 10) {
                    player.sendMessage(ChatColor.RED + "La cantidad mínima es $10!");
                    return true;
                }
                
                if (amount > 1000000) {
                    player.sendMessage(ChatColor.RED + "No puedes enviar más de $1,000,000 a la vez!");
                    return true;
                }
                
                if (plugin.getEconomyManager().transferMoney(player.getUniqueId(), target.getUniqueId(), amount)) {
                    player.sendMessage(ChatColor.GREEN + "💸 Has enviado $" + String.format("%.2f", amount) + " a " + target.getName());
                    player.sendMessage(ChatColor.GRAY + "Nuevo saldo: $" + 
                        String.format("%.2f", plugin.getEconomyManager().getBalance(player.getUniqueId())));
                    
                    target.sendMessage(ChatColor.GREEN + "💰 Has recibido $" + String.format("%.2f", amount) + " de " + player.getName());
                    target.sendMessage(ChatColor.GRAY + "Nuevo saldo: $" + 
                        String.format("%.2f", plugin.getEconomyManager().getBalance(target.getUniqueId())));
                } else {
                    player.sendMessage(ChatColor.RED + "No tienes suficiente dinero!");
                    player.sendMessage(ChatColor.GRAY + "Tu saldo: $" + 
                        String.format("%.2f", plugin.getEconomyManager().getBalance(player.getUniqueId())));
                }
                
            } catch (NumberFormatException e) {
                player.sendMessage(ChatColor.RED + "Cantidad inválida!");
                player.sendMessage(ChatColor.GRAY + "Ejemplo: /pay " + args[0] + " 100");
            }
        }
        
        return true;
    }
}