package com.allinone.commands;

import com.allinone.AllInOnePlugin;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class AuctionCommand implements CommandExecutor {
    
    private final AllInOnePlugin plugin;
    
    public AuctionCommand(AllInOnePlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Solo los jugadores pueden usar este comando!");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (!player.hasPermission("allinone.ah")) {
            player.sendMessage(ChatColor.RED + "No tienes permisos para usar este comando!");
            return true;
        }
        
        // /ah sin argumentos - abrir GUI
        if (args.length == 0) {
            plugin.getAuctionManager().openAuctionHouse(player);
            return true;
        }
        
        // /ah sell <precio> [cantidad]
        if (args[0].equalsIgnoreCase("sell")) {
            return handleSellCommand(player, args);
        }
        
        // Otros subcomandos futuros
        player.sendMessage(ChatColor.RED + "Uso: /ah [sell <precio> [cantidad]]");
        return true;
    }
    
    private boolean handleSellCommand(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(ChatColor.RED + "Uso: /ah sell <precio> [cantidad]");
            player.sendMessage(ChatColor.GRAY + "Ejemplo: /ah sell 1000 32");
            return true;
        }
        
        try {
            double price = Double.parseDouble(args[1]);
            int amount = 1;
            
            if (args.length >= 3) {
                amount = Integer.parseInt(args[2]);
            }
            
            ItemStack item = player.getInventory().getItemInMainHand();
            
            if (amount <= 0) {
                player.sendMessage(ChatColor.RED + "La cantidad debe ser mayor a 0!");
                return true;
            }
            
            // Si no especifica cantidad, usar toda la stack
            if (args.length == 2) {
                amount = item.getAmount();
            }
            
            plugin.getAuctionManager().sellItem(player, item, price, amount);
            
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "Precio o cantidad inválida!");
            player.sendMessage(ChatColor.GRAY + "Ejemplo: /ah sell 1000 32");
        }
        
        return true;
    }
}