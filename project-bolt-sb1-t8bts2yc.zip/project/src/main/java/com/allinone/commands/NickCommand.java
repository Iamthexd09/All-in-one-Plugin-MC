package com.allinone.commands;

import com.allinone.AllInOnePlugin;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class NickCommand implements CommandExecutor {
    
    private final AllInOnePlugin plugin;
    
    public NickCommand(AllInOnePlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Solo los jugadores pueden usar este comando!");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (!player.hasPermission("allinone.nick")) {
            player.sendMessage(ChatColor.RED + "No tienes permisos para usar este comando!");
            return true;
        }
        
        if (args.length == 0) {
            player.sendMessage(ChatColor.RED + "Uso: /nick <nombre>");
            player.sendMessage(ChatColor.GRAY + "Usa códigos de color como &1, &2, &a, &c, etc.");
            return true;
        }
        
        String nickname = String.join(" ", args);
        
        // Validar longitud
        if (nickname.length() > 16) {
            player.sendMessage(ChatColor.RED + "El nickname no puede tener más de 16 caracteres!");
            return true;
        }
        
        // Aplicar códigos de color
        String coloredNickname = ChatColor.translateAlternateColorCodes('&', nickname);
        
        // Guardar en base de datos
        plugin.getRankManager().setPlayerNickname(player.getUniqueId(), nickname, "");
        
        player.sendMessage(ChatColor.GREEN + "Tu nickname ha sido cambiado a: " + coloredNickname);
        
        return true;
    }
}