@@ .. @@
                 // Proteger items con encantamientos custom
                 if (plugin.getCustomEnchantManager().hasCustomEnchant(item, "lightning") ||
                     plugin.getCustomEnchantManager().hasCustomEnchant(item, "vampire") ||
                     plugin.getCustomEnchantManager().hasCustomEnchant(item, "explosive")) {
                     continue;
                 }
                 
-                // Proteger billetes de dinero del sistema withdraw
-                if (WithdrawCommand.isMoneyNote(item)) {
-                    continue;
-                }
+                // Proteger billetes de dinero del sistema withdraw
+                if (WithdrawCommand.isMoneyNote(item)) {
+                    protectedCount++;
+                    continue;
+                }
                 
                 // Si llegamos aquí, el item se puede borrar
                 inventory.setItem(i, null);
                 removedCount++;
             }
         }
         
         // Mensajes informativos
         if (removedCount > 0) {
             player.sendMessage(ChatColor.GREEN + "🧹 Inventario limpiado! Items eliminados: " + removedCount);
             if (protectedCount > 0) {
-                player.sendMessage(ChatColor.YELLOW + "🛡️ Items protegidos (con encantamientos): " + protectedCount);
+                player.sendMessage(ChatColor.YELLOW + "🛡️ Items protegidos (encantamientos/billetes): " + protectedCount);
             }
         } else if (protectedCount > 0) {
-            player.sendMessage(ChatColor.YELLOW + "🛡️ Solo tienes items protegidos (con encantamientos)!");
+            player.sendMessage(ChatColor.YELLOW + "🛡️ Solo tienes items protegidos (encantamientos/billetes)!");
         } else {
             player.sendMessage(ChatColor.GRAY + "🧹 Tu inventario ya estaba vacío!");
         }