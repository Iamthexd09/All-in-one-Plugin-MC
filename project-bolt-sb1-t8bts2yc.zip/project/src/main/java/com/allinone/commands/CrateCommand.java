package com.allinone.commands;

import com.allinone.AllInOnePlugin;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.Random;

public class CrateCommand implements CommandExecutor {
    
    private final AllInOnePlugin plugin;
    private final Random random = new Random();
    
    public CrateCommand(AllInOnePlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Solo los jugadores pueden usar este comando!");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (!player.hasPermission("allinone.crate")) {
            player.sendMessage(ChatColor.RED + "No tienes permisos para usar este comando!");
            return true;
        }
        
        if (args.length == 0) {
            // Abrir GUI de crates
            plugin.getCrateManager().openCrateGUI(player);
            return true;
        }
        
        String crateType = args[0].toLowerCase();
        plugin.getCrateManager().openCrate(player, crateType);
        
        return true;
    }
}