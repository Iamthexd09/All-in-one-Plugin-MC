package com.allinone.commands;

import com.allinone.AllInOnePlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SpawnCommand implements CommandExecutor {
    
    private final AllInOnePlugin plugin;
    
    public SpawnCommand(AllInOnePlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("spawn")) {
            return handleSpawnCommand(sender, args);
        } else if (label.equalsIgnoreCase("setspawn")) {
            return handleSetSpawnCommand(sender, args);
        }
        return false;
    }
    
    private boolean handleSpawnCommand(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Solo los jugadores pueden usar este comando!");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (!player.hasPermission("allinone.spawn")) {
            player.sendMessage(ChatColor.RED + "No tienes permisos para usar este comando!");
            return true;
        }
        
        Location spawnLocation = getSpawnLocation();
        if (spawnLocation == null) {
            // Si no hay spawn personalizado, usar spawn del mundo
            spawnLocation = player.getWorld().getSpawnLocation();
        }
        
        player.teleport(spawnLocation);
        player.sendMessage(ChatColor.GREEN + "¡Te has teletransportado al spawn!");
        
        return true;
    }
    
    private boolean handleSetSpawnCommand(CommandSender sender, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Solo los jugadores pueden usar este comando!");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (!player.hasPermission("allinone.setspawn")) {
            player.sendMessage(ChatColor.RED + "No tienes permisos para usar este comando!");
            return true;
        }
        
        Location loc = player.getLocation();
        
        try {
            // Eliminar spawn anterior si existe
            plugin.getDatabaseManager().executeUpdate("DELETE FROM spawn_location");
            
            // Establecer nuevo spawn
            plugin.getDatabaseManager().executeUpdate(
                "INSERT INTO spawn_location (world, x, y, z, yaw, pitch) VALUES (?, ?, ?, ?, ?, ?)",
                loc.getWorld().getName(), loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), loc.getPitch());
            
            player.sendMessage(ChatColor.GREEN + "¡Spawn establecido correctamente!");
            
        } catch (SQLException e) {
            e.printStackTrace();
            player.sendMessage(ChatColor.RED + "Error al establecer el spawn!");
        }
        
        return true;
    }
    
    private Location getSpawnLocation() {
        try {
            ResultSet rs = plugin.getDatabaseManager().executeQuery("SELECT * FROM spawn_location LIMIT 1");
            
            if (rs.next()) {
                World world = Bukkit.getWorld(rs.getString("world"));
                if (world != null) {
                    return new Location(world,
                        rs.getDouble("x"), rs.getDouble("y"), rs.getDouble("z"),
                        rs.getFloat("yaw"), rs.getFloat("pitch"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}