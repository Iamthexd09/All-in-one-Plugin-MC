package com.allinone.commands;

import com.allinone.AllInOnePlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class TeleportCommand implements CommandExecutor {
    
    private final AllInOnePlugin plugin;
    private final Map<UUID, UUID> teleportRequests = new HashMap<>(); // Solicitante -> Objetivo
    private final Map<UUID, Long> requestTimes = new HashMap<>(); // Para timeout
    
    public TeleportCommand(AllInOnePlugin plugin) {
        this.plugin = plugin;
        startRequestCleaner();
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Solo los jugadores pueden usar este comando!");
            return true;
        }
        
        Player player = (Player) sender;
        
        switch (label.toLowerCase()) {
            case "tpa":
                return handleTpaCommand(player, args);
            case "tpaccept":
                return handleTpAcceptCommand(player, args);
            case "tpacancel":
                return handleTpaCancelCommand(player, args);
            default:
                return false;
        }
    }
    
    private boolean handleTpaCommand(Player player, String[] args) {
        if (!player.hasPermission("allinone.tpa")) {
            player.sendMessage(ChatColor.RED + "No tienes permisos para usar este comando!");
            return true;
        }
        
        if (args.length != 1) {
            player.sendMessage(ChatColor.RED + "Uso: /tpa <jugador>");
            return true;
        }
        
        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "El jugador no está en línea!");
            return true;
        }
        
        if (target.equals(player)) {
            player.sendMessage(ChatColor.RED + "No puedes enviarte una solicitud a ti mismo!");
            return true;
        }
        
        // Verificar si ya hay una solicitud pendiente
        if (teleportRequests.containsKey(player.getUniqueId())) {
            player.sendMessage(ChatColor.RED + "Ya tienes una solicitud de teletransporte pendiente!");
            return true;
        }
        
        // Crear solicitud
        teleportRequests.put(player.getUniqueId(), target.getUniqueId());
        requestTimes.put(player.getUniqueId(), System.currentTimeMillis());
        
        // Mensajes
        player.sendMessage(ChatColor.GREEN + "Solicitud de teletransporte enviada a " + target.getName() + "!");
        
        target.sendMessage(ChatColor.YELLOW + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        target.sendMessage(ChatColor.GOLD + "📨 " + ChatColor.WHITE + player.getName() + ChatColor.YELLOW + " quiere teletransportarse a ti");
        target.sendMessage(ChatColor.GREEN + "▸ /tpaccept " + player.getName() + ChatColor.GRAY + " - Aceptar");
        target.sendMessage(ChatColor.RED + "▸ /tpacancel " + player.getName() + ChatColor.GRAY + " - Rechazar");
        target.sendMessage(ChatColor.GRAY + "La solicitud expira en 60 segundos");
        target.sendMessage(ChatColor.YELLOW + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        
        return true;
    }
    
    private boolean handleTpAcceptCommand(Player player, String[] args) {
        if (!player.hasPermission("allinone.tpaccept")) {
            player.sendMessage(ChatColor.RED + "No tienes permisos para usar este comando!");
            return true;
        }
        
        UUID requesterUUID = null;
        
        // Si especifica un jugador
        if (args.length == 1) {
            Player requester = Bukkit.getPlayer(args[0]);
            if (requester == null) {
                player.sendMessage(ChatColor.RED + "El jugador no está en línea!");
                return true;
            }
            requesterUUID = requester.getUniqueId();
        } else {
            // Buscar cualquier solicitud hacia este jugador
            for (Map.Entry<UUID, UUID> entry : teleportRequests.entrySet()) {
                if (entry.getValue().equals(player.getUniqueId())) {
                    requesterUUID = entry.getKey();
                    break;
                }
            }
        }
        
        if (requesterUUID == null || !teleportRequests.containsKey(requesterUUID)) {
            player.sendMessage(ChatColor.RED + "No tienes solicitudes de teletransporte pendientes!");
            return true;
        }
        
        Player requester = Bukkit.getPlayer(requesterUUID);
        if (requester == null) {
            teleportRequests.remove(requesterUUID);
            requestTimes.remove(requesterUUID);
            player.sendMessage(ChatColor.RED + "El jugador que envió la solicitud ya no está en línea!");
            return true;
        }
        
        // Verificar protección
        if (!plugin.getProtectionManager().canTeleportTo(requester, player.getLocation())) {
            player.sendMessage(ChatColor.RED + "No se puede teletransportar a una zona protegida!");
            requester.sendMessage(ChatColor.RED + "No se pudo completar el teletransporte (zona protegida)!");
            teleportRequests.remove(requesterUUID);
            requestTimes.remove(requesterUUID);
            return true;
        }
        
        // Realizar teletransporte
        requester.teleport(player.getLocation());
        
        // Mensajes de éxito
        player.sendMessage(ChatColor.GREEN + "✓ Has aceptado la solicitud de " + requester.getName() + "!");
        requester.sendMessage(ChatColor.GREEN + "✓ " + player.getName() + " ha aceptado tu solicitud!");
        requester.sendMessage(ChatColor.GOLD + "¡Te has teletransportado exitosamente!");
        
        // Limpiar solicitud
        teleportRequests.remove(requesterUUID);
        requestTimes.remove(requesterUUID);
        
        return true;
    }
    
    private boolean handleTpaCancelCommand(Player player, String[] args) {
        if (!player.hasPermission("allinone.tpacancel")) {
            player.sendMessage(ChatColor.RED + "No tienes permisos para usar este comando!");
            return true;
        }
        
        // Caso 1: El jugador cancela su propia solicitud
        if (teleportRequests.containsKey(player.getUniqueId())) {
            UUID targetUUID = teleportRequests.get(player.getUniqueId());
            Player target = Bukkit.getPlayer(targetUUID);
            
            teleportRequests.remove(player.getUniqueId());
            requestTimes.remove(player.getUniqueId());
            
            player.sendMessage(ChatColor.YELLOW + "Has cancelado tu solicitud de teletransporte!");
            if (target != null) {
                target.sendMessage(ChatColor.YELLOW + player.getName() + " ha cancelado su solicitud de teletransporte.");
            }
            return true;
        }
        
        // Caso 2: El jugador rechaza una solicitud hacia él
        UUID requesterUUID = null;
        
        if (args.length == 1) {
            Player requester = Bukkit.getPlayer(args[0]);
            if (requester == null) {
                player.sendMessage(ChatColor.RED + "El jugador no está en línea!");
                return true;
            }
            requesterUUID = requester.getUniqueId();
        } else {
            // Buscar cualquier solicitud hacia este jugador
            for (Map.Entry<UUID, UUID> entry : teleportRequests.entrySet()) {
                if (entry.getValue().equals(player.getUniqueId())) {
                    requesterUUID = entry.getKey();
                    break;
                }
            }
        }
        
        if (requesterUUID == null || !teleportRequests.containsKey(requesterUUID)) {
            player.sendMessage(ChatColor.RED + "No tienes solicitudes de teletransporte para cancelar!");
            return true;
        }
        
        Player requester = Bukkit.getPlayer(requesterUUID);
        
        teleportRequests.remove(requesterUUID);
        requestTimes.remove(requesterUUID);
        
        player.sendMessage(ChatColor.YELLOW + "Has rechazado la solicitud de teletransporte!");
        if (requester != null) {
            requester.sendMessage(ChatColor.RED + player.getName() + " ha rechazado tu solicitud de teletransporte.");
        }
        
        return true;
    }
    
    private void startRequestCleaner() {
        new BukkitRunnable() {
            @Override
            public void run() {
                long currentTime = System.currentTimeMillis();
                
                teleportRequests.entrySet().removeIf(entry -> {
                    UUID requesterUUID = entry.getKey();
                    Long requestTime = requestTimes.get(requesterUUID);
                    
                    if (requestTime != null && currentTime - requestTime > 60000) { // 60 segundos
                        Player requester = Bukkit.getPlayer(requesterUUID);
                        Player target = Bukkit.getPlayer(entry.getValue());
                        
                        if (requester != null) {
                            requester.sendMessage(ChatColor.RED + "Tu solicitud de teletransporte ha expirado.");
                        }
                        if (target != null) {
                            target.sendMessage(ChatColor.GRAY + "Una solicitud de teletransporte ha expirado.");
                        }
                        
                        requestTimes.remove(requesterUUID);
                        return true;
                    }
                    return false;
                });
            }
        }.runTaskTimer(plugin, 20L, 20L); // Verificar cada segundo
    }
}