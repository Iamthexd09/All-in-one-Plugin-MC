package com.allinone.commands;

import com.allinone.AllInOnePlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class ShopCommand implements CommandExecutor {
    
    private final AllInOnePlugin plugin;
    
    public ShopCommand(AllInOnePlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Solo los jugadores pueden usar este comando!");
            return true;
        }
        
        Player player = (Player) sender;
        
        if (!player.hasPermission("allinone.shop")) {
            player.sendMessage(ChatColor.RED + "No tienes permisos para usar este comando!");
            return true;
        }
        
        openShopGUI(player);
        return true;
    }
    
    private void openShopGUI(Player player) {
        Inventory shop = Bukkit.createInventory(null, 54, ChatColor.DARK_GREEN + "▸ Tienda");
        
        // Bloques básicos
        addShopItem(shop, 0, Material.STONE, "Piedra", 5, 2);
        addShopItem(shop, 1, Material.COBBLESTONE, "Adoquín", 3, 1);
        addShopItem(shop, 2, Material.DIRT, "Tierra", 2, 1);
        addShopItem(shop, 3, Material.SAND, "Arena", 4, 2);
        addShopItem(shop, 4, Material.GRAVEL, "Grava", 3, 1);
        
        // Madera
        addShopItem(shop, 9, Material.OAK_LOG, "Tronco de Roble", 8, 4);
        addShopItem(shop, 10, Material.BIRCH_LOG, "Tronco de Abedul", 10, 5);
        addShopItem(shop, 11, Material.SPRUCE_LOG, "Tronco de Abeto", 9, 4);
        
        // Herramientas
        addShopItem(shop, 18, Material.WOODEN_PICKAXE, "Pico de Madera", 15, 5);
        addShopItem(shop, 19, Material.STONE_PICKAXE, "Pico de Piedra", 30, 10);
        addShopItem(shop, 20, Material.IRON_PICKAXE, "Pico de Hierro", 100, 30);
        
        // Comida
        addShopItem(shop, 27, Material.BREAD, "Pan", 10, 3);
        addShopItem(shop, 28, Material.COOKED_BEEF, "Carne Cocida", 15, 5);
        addShopItem(shop, 29, Material.APPLE, "Manzana", 8, 3);
        
        // Minerales
        addShopItem(shop, 36, Material.COAL, "Carbón", 5, 2);
        addShopItem(shop, 37, Material.IRON_INGOT, "Lingote de Hierro", 20, 8);
        addShopItem(shop, 38, Material.GOLD_INGOT, "Lingote de Oro", 50, 20);
        addShopItem(shop, 39, Material.DIAMOND, "Diamante", 200, 80);
        
        // Semillas
        addShopItem(shop, 45, Material.WHEAT_SEEDS, "Semillas de Trigo", 3, 1);
        addShopItem(shop, 46, Material.CARROT, "Zanahoria", 5, 2);
        addShopItem(shop, 47, Material.POTATO, "Patata", 4, 2);
        
        player.openInventory(shop);
    }
    
    private void addShopItem(Inventory inventory, int slot, Material material, String name, double buyPrice, double sellPrice) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        
        meta.setDisplayName(ChatColor.YELLOW + name);
        meta.setLore(Arrays.asList(
            ChatColor.GREEN + "Comprar: $" + buyPrice,
            ChatColor.RED + "Vender: $" + sellPrice,
            "",
            ChatColor.GRAY + "Click izquierdo: Comprar x1",
            ChatColor.GRAY + "Click derecho: Vender x1",
            ChatColor.GRAY + "Shift + Click: Comprar/Vender x64"
        ));
        
        item.setItemMeta(meta);
        inventory.setItem(slot, item);
    }
}