package com.allinone.scoreboard;

import com.allinone.AllInOnePlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ScoreboardManager {
    
    private final AllInOnePlugin plugin;
    private final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
    
    public ScoreboardManager(AllInOnePlugin plugin) {
        this.plugin = plugin;
        startScoreboardUpdater();
    }
    
    public void setPlayerScoreboard(Player player) {
        Scoreboard scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective objective = scoreboard.registerNewObjective("main", "dummy", 
            ChatColor.GOLD + "▸ " + ChatColor.BOLD + "MI SERVIDOR" + ChatColor.GOLD + " ◂");
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        
        updateScoreboard(player, objective);
        player.setScoreboard(scoreboard);
    }
    
    private void updateScoreboard(Player player, Objective objective) {
        // Limpiar scores existentes
        for (String entry : objective.getScoreboard().getEntries()) {
            objective.getScoreboard().resetScores(entry);
        }
        
        String playerRank = plugin.getRankManager().getPlayerRank(player.getUniqueId());
        double balance = plugin.getEconomyManager().getBalance(player.getUniqueId());
        String time = timeFormat.format(new Date());
        
        setScore(objective, ChatColor.WHITE + " ", 15);
        setScore(objective, ChatColor.AQUA + "Jugador:", 14);
        setScore(objective, ChatColor.WHITE + " " + player.getName(), 13);
        setScore(objective, ChatColor.WHITE + "  ", 12);
        setScore(objective, ChatColor.GOLD + "Rango:", 11);
        setScore(objective, ChatColor.WHITE + " " + playerRank, 10);
        setScore(objective, ChatColor.WHITE + "   ", 9);
        setScore(objective, ChatColor.GREEN + "Dinero:", 8);
        setScore(objective, ChatColor.WHITE + " $" + String.format("%.2f", balance), 7);
        setScore(objective, ChatColor.WHITE + "    ", 6);
        setScore(objective, ChatColor.YELLOW + "En línea:", 5);
        setScore(objective, ChatColor.WHITE + " " + Bukkit.getOnlinePlayers().size() + "/" + Bukkit.getMaxPlayers(), 4);
        setScore(objective, ChatColor.WHITE + "     ", 3);
        setScore(objective, ChatColor.LIGHT_PURPLE + "Hora:", 2);
        setScore(objective, ChatColor.WHITE + " " + time, 1);
        setScore(objective, ChatColor.WHITE + "      ", 0);
    }
    
    private void setScore(Objective objective, String text, int score) {
        Score s = objective.getScore(text);
        s.setScore(score);
    }
    
    private void startScoreboardUpdater() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (player.getScoreboard() != null) {
                        Objective objective = player.getScoreboard().getObjective("main");
                        if (objective != null) {
                            updateScoreboard(player, objective);
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 20L, 20L); // Actualizar cada segundo
    }
}