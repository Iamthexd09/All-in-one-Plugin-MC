@@ .. @@
 import com.allinone.AllInOnePlugin;
+import org.bukkit.ChatColor;
 import org.bukkit.Material;
 import org.bukkit.block.Block;
+import org.bukkit.enchantments.Enchantment;
 import org.bukkit.entity.Player;
 import org.bukkit.event.EventHandler;
 import org.bukkit.event.Listener;
 import org.bukkit.event.block.BlockPlaceEvent;
+import org.bukkit.inventory.ItemStack;
+import org.bukkit.inventory.meta.ItemMeta;
 
 public class ProtectionListener implements Listener {
     
@@ -21,12 +27,21 @@ public class ProtectionListener implements Listener {
         Block block = event.getBlock();
         Material material = block.getType();
         
+        // Verificar si es una piedra de protección
         if (plugin.getProtectionManager().isProtectionStone(material)) {
-            String protectionType = plugin.getProtectionManager().getProtectionType(material);
-            
-            if (plugin.getProtectionManager().createProtection(player, block.getLocation(), protectionType)) {
-                player.sendMessage("¡Piedra protectora activada!");
+            // Verificar si el item tiene el formato correcto de piedra protectora
+            ItemStack item = event.getItemInHand();
+            if (isValidProtectionStone(item, material)) {
+                if (plugin.getProtectionManager().createProtection(player, block.getLocation(), material)) {
+                    // Protección creada exitosamente
+                } else {
+                    event.setCancelled(true);
+                }
             } else {
+                // No es una piedra protectora válida, permitir colocación normal
+            }
+        }
+    }
+    
+    private boolean isValidProtectionStone(ItemStack item, Material material) {
+        if (item == null || item.getType() != material) return false;
+        if (!item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) return false;
+        
+        String displayName = item.getItemMeta().getDisplayName();
+        return displayName.contains("Protección");
+    }
+}