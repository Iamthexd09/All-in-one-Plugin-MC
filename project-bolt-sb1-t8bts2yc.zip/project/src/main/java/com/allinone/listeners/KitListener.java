package com.allinone.listeners;

import com.allinone.AllInOnePlugin;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class KitListener implements Listener {
    
    private final AllInOnePlugin plugin;
    
    public KitListener(AllInOnePlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        
        Player player = (Player) event.getWhoClicked();
        String title = event.getView().getTitle();
        
        if (title.contains("Kits Disponibles")) {
            event.setCancelled(true);
            
            ItemStack clicked = event.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;
            
            String displayName = clicked.getItemMeta().getDisplayName();
            if (displayName.contains("Kit ")) {
                String kitName = displayName.toLowerCase()
                    .replace("✓ kit ", "")
                    .replace("✗ kit ", "")
                    .replace(ChatColor.GREEN.toString(), "")
                    .replace(ChatColor.RED.toString(), "");
                
                player.closeInventory();
                plugin.getKitManager().giveKit(player, kitName);
            }
        }
        
        if (title.contains("Crates Disponibles")) {
            event.setCancelled(true);
            
            ItemStack clicked = event.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;
            
            String displayName = clicked.getItemMeta().getDisplayName();
            if (displayName.contains("Crate ")) {
                String crateName = displayName.toLowerCase()
                    .replace("crate ", "")
                    .replace(ChatColor.GOLD.toString(), "");
                
                player.closeInventory();
                plugin.getCrateManager().openCrate(player, crateName);
            }
        }
    }
}