package com.allinone.listeners;

import com.allinone.AllInOnePlugin;
import com.allinone.commands.WithdrawCommand;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class MoneyNoteListener implements Listener {
    
    private final AllInOnePlugin plugin;
    
    public MoneyNoteListener(AllInOnePlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        
        if (!WithdrawCommand.isMoneyNote(item)) return;
        
        event.setCancelled(true);
        
        double value = WithdrawCommand.getMoneyNoteValue(item);
        if (value <= 0) {
            player.sendMessage(ChatColor.RED + "Billete inválido!");
            return;
        }
        
        // Depositar dinero
        plugin.getEconomyManager().addBalance(player.getUniqueId(), value);
        
        // Remover billete del inventario
        if (item.getAmount() > 1) {
            item.setAmount(item.getAmount() - 1);
        } else {
            player.getInventory().setItemInMainHand(null);
        }
        
        player.sendMessage(ChatColor.GREEN + "¡Has depositado $" + String.format("%.2f", value) + " a tu cuenta!");
        player.sendMessage(ChatColor.GRAY + "Nuevo saldo: $" + 
            String.format("%.2f", plugin.getEconomyManager().getBalance(player.getUniqueId())));
    }
}