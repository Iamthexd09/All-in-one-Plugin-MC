package com.allinone.listeners;

import com.allinone.AllInOnePlugin;
import com.allinone.managers.RankManager;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatListener implements Listener {
    
    private final AllInOnePlugin plugin;
    private final RankManager rankManager;
    
    public ChatListener(AllInOnePlugin plugin) {
        this.plugin = plugin;
        this.rankManager = plugin.getRankManager();
    }
    
    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        String message = event.getMessage();
        
        // Aplicar códigos de color si tiene permisos
        if (player.hasPermission("allinone.chatcolor")) {
            message = ChatColor.translateAlternateColorCodes('&', message);
        }
        
        // Obtener información del rango
        String prefix = rankManager.getPlayerPrefix(player.getUniqueId());
        String suffix = rankManager.getPlayerSuffix(player.getUniqueId());
        String nickname = rankManager.getPlayerNickname(player.getUniqueId());
        
        // Construir formato del chat
        String displayName = nickname != null ? nickname : player.getName();
        String format = prefix + displayName + suffix + ChatColor.WHITE + ": " + message;
        
        event.setFormat(format);
    }
}