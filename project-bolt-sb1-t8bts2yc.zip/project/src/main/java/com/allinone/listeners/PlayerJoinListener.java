package com.allinone.listeners;

import com.allinone.AllInOnePlugin;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class PlayerJoinListener implements Listener {
    
    private final AllInOnePlugin plugin;
    
    public PlayerJoinListener(AllInOnePlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        
        // Configurar scoreboard
        plugin.getScoreboardManager().setPlayerScoreboard(player);
        
        // Mensaje de bienvenida personalizado
        String playerName = plugin.getRankManager().getPlayerNickname(player.getUniqueId());
        if (playerName == null) {
            playerName = player.getName();
        }
        
        String rank = plugin.getRankManager().getPlayerRank(player.getUniqueId());
        
        event.setJoinMessage(ChatColor.GREEN + "+ " + ChatColor.GRAY + "[" + rank + "] " + 
                            ChatColor.WHITE + playerName + ChatColor.GRAY + " se unió al servidor");
        
        // Dar dinero inicial a nuevos jugadores
        if (!player.hasPlayedBefore()) {
            // Establecer saldo inicial de $5000
            plugin.getEconomyManager().setBalance(player.getUniqueId(), 5000.0);
            
            // Dar kit inicial completo
            giveStarterKit(player);
            
            player.sendMessage(ChatColor.GOLD + "¡Bienvenido al servidor!");
            player.sendMessage(ChatColor.GREEN + "💰 Has recibido $5,000 iniciales");
            player.sendMessage(ChatColor.AQUA + "🎒 Kit inicial añadido a tu inventario");
            player.sendMessage(ChatColor.LIGHT_PURPLE + "🛡️ Piedra de protección incluida");
        }
    }
    
    private void giveStarterKit(Player player) {
        // Armadura de hierro completa con Protección I
        ItemStack helmet = createEnchantedArmor(Material.IRON_HELMET, "Casco de Hierro Inicial");
        ItemStack chestplate = createEnchantedArmor(Material.IRON_CHESTPLATE, "Pechera de Hierro Inicial");
        ItemStack leggings = createEnchantedArmor(Material.IRON_LEGGINGS, "Pantalones de Hierro Iniciales");
        ItemStack boots = createEnchantedArmor(Material.IRON_BOOTS, "Botas de Hierro Iniciales");
        
        // Equipar armadura
        player.getInventory().setHelmet(helmet);
        player.getInventory().setChestplate(chestplate);
        player.getInventory().setLeggings(leggings);
        player.getInventory().setBoots(boots);
        
        // Espada de hierro con Filo I
        ItemStack sword = new ItemStack(Material.IRON_SWORD);
        ItemMeta swordMeta = sword.getItemMeta();
        swordMeta.setDisplayName(ChatColor.AQUA + "Espada de Hierro Inicial");
        swordMeta.addEnchant(Enchantment.DAMAGE_ALL, 1, true);
        sword.setItemMeta(swordMeta);
        
        // Herramientas con Eficiencia I
        ItemStack pickaxe = createEnchantedTool(Material.IRON_PICKAXE, "Pico de Hierro Inicial", Enchantment.DIG_SPEED);
        ItemStack axe = createEnchantedTool(Material.IRON_AXE, "Hacha de Hierro Inicial", Enchantment.DIG_SPEED);
        ItemStack shovel = createEnchantedTool(Material.IRON_SHOVEL, "Pala de Hierro Inicial", Enchantment.DIG_SPEED);
        
        // Azada con Fortuna I
        ItemStack hoe = createEnchantedTool(Material.IRON_HOE, "Azada de Hierro Inicial", Enchantment.LOOT_BONUS_BLOCKS);
        
        // Comida
        ItemStack food = new ItemStack(Material.COOKED_PORKCHOP, 64);
        
        // Piedra de protección de carbón
        ItemStack protectionStone = plugin.getProtectionManager().createProtectionStone(Material.COAL_ORE);
        
        // Añadir items al inventario
        player.getInventory().addItem(sword, pickaxe, axe, shovel, hoe, food, protectionStone);
    }
    
    private ItemStack createEnchantedArmor(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + name);
        meta.addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 1, true);
        item.setItemMeta(meta);
        return item;
    }
    
    private ItemStack createEnchantedTool(Material material, String name, Enchantment enchantment) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + name);
        if (enchantment == Enchantment.LOOT_BONUS_BLOCKS) {
            meta.addEnchant(enchantment, 1, true); // Fortuna I para azada
        } else {
            meta.addEnchant(enchantment, 1, true); // Eficiencia I para otras herramientas
        }
        item.setItemMeta(meta);
        return item;
    }
}