package com.allinone;

import com.allinone.commands.*;
import com.allinone.listeners.*;
import com.allinone.managers.*;
import com.allinone.database.DatabaseManager;
import com.allinone.scoreboard.ScoreboardManager;
import com.allinone.managers.CustomEnchantManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.PluginManager;

public class AllInOnePlugin extends JavaPlugin {
    
    private static AllInOnePlugin instance;
    private DatabaseManager databaseManager;
    private EconomyManager economyManager;
    private HomeManager homeManager;
    private ShopManager shopManager;
    private AuctionManager auctionManager;
    private CrateManager crateManager;
    private BackpackManager backpackManager;
    private RankManager rankManager;
    private KitManager kitManager;
    private WarpManager warpManager;
    private NPCManager npcManager;
    private ScoreboardManager scoreboardManager;
    private ProtectionManager protectionManager;
    private CustomEnchantManager customEnchantManager;
    
    @Override
    public void onEnable() {
        instance = this;
        
        // Crear config por defecto
        saveDefaultConfig();
        
        // Inicializar base de datos
        databaseManager = new DatabaseManager(this);
        
        // Inicializar managers
        initializeManagers();
        
        // Registrar comandos
        registerCommands();
        
        // Registrar eventos
        registerEvents();
        
        getLogger().info("All-in-one Plugin habilitado correctamente!");
    }
    
    @Override
    public void onDisable() {
        if (databaseManager != null) {
            databaseManager.close();
        }
        getLogger().info("All-in-one Plugin deshabilitado!");
    }
    
    private void initializeManagers() {
        economyManager = new EconomyManager(this);
        homeManager = new HomeManager(this);
        shopManager = new ShopManager(this);
        auctionManager = new AuctionManager(this);
        crateManager = new CrateManager(this);
        backpackManager = new BackpackManager(this);
        rankManager = new RankManager(this);
        kitManager = new KitManager(this);
        warpManager = new WarpManager(this);
        npcManager = new NPCManager(this);
        scoreboardManager = new ScoreboardManager(this);
        protectionManager = new ProtectionManager(this);
        customEnchantManager = new CustomEnchantManager(this);
    }
    
    private void registerCommands() {
        getCommand("tpa").setExecutor(new TeleportCommand(this));
        getCommand("tpaccept").setExecutor(new TeleportCommand(this));
        getCommand("tpacancel").setExecutor(new TeleportCommand(this));
        getCommand("sethome").setExecutor(new HomeCommand(this));
        getCommand("home").setExecutor(new HomeCommand(this));
        getCommand("shop").setExecutor(new ShopCommand(this));
        getCommand("ah").setExecutor(new AuctionCommand(this));
        getCommand("crate").setExecutor(new CrateCommand(this));
        getCommand("backpack").setExecutor(new BackpackCommand(this));
        getCommand("rank").setExecutor(new RankCommand(this));
        getCommand("rtp").setExecutor(new RTPCommand(this));
        getCommand("kit").setExecutor(new KitCommand(this));
        getCommand("warp").setExecutor(new WarpCommand(this));
        getCommand("setwarp").setExecutor(new WarpCommand(this));
        getCommand("nick").setExecutor(new NickCommand(this));
        getCommand("chatcolor").setExecutor(new ChatColorCommand(this));
        getCommand("money").setExecutor(new EconomyCommand(this));
        getCommand("pay").setExecutor(new EconomyCommand(this));
        getCommand("spawn").setExecutor(new SpawnCommand(this));
        getCommand("setspawn").setExecutor(new SpawnCommand(this));
        getCommand("withdraw").setExecutor(new WithdrawCommand(this));
        getCommand("npc").setExecutor(new NPCCommand(this));
    }
    
    private void registerEvents() {
        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new PlayerJoinListener(this), this);
        pm.registerEvents(new ChatListener(this), this);
        pm.registerEvents(new ProtectionListener(this), this);
        pm.registerEvents(new NPCListener(this), this);
        pm.registerEvents(new BackpackListener(this), this);
        pm.registerEvents(new KitListener(this), this);
        pm.registerEvents(new MoneyNoteListener(this), this);
    }
    
    // Getters estáticos
    public static AllInOnePlugin getInstance() { return instance; }
    public DatabaseManager getDatabaseManager() { return databaseManager; }
    public EconomyManager getEconomyManager() { return economyManager; }
    public HomeManager getHomeManager() { return homeManager; }
    public ShopManager getShopManager() { return shopManager; }
    public AuctionManager getAuctionManager() { return auctionManager; }
    public CrateManager getCrateManager() { return crateManager; }
    public BackpackManager getBackpackManager() { return backpackManager; }
    public RankManager getRankManager() { return rankManager; }
    public KitManager getKitManager() { return kitManager; }
    public WarpManager getWarpManager() { return warpManager; }
    public NPCManager getNPCManager() { return npcManager; }
    public ScoreboardManager getScoreboardManager() { return scoreboardManager; }
    public ProtectionManager getProtectionManager() { return protectionManager; }
    public CustomEnchantManager getCustomEnchantManager() { return customEnchantManager; }
}